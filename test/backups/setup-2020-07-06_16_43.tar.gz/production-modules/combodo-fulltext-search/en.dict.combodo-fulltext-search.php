<?php
/**
 *
 * @copyright   Copyright (C) 2010-2019 Combodo SARL
 * @license     https://www.combodo.com/documentation/combodo-software-license.html
 *
 */

Dict::Add('EN US', 'English', 'English', array(
	// Dictionary entries go here
	'Menu:GlobalSearchManagement' => 'Global search management',
	'combodo-fulltext-search/Operation:DisplayRelated/Title' => 'Related objects',
	'combodo-fulltext-search/Operation:Search/Title' => 'Search',
	'combodo-fulltext-search/Operation:Admin/Title' => 'Global search management',
	'combodo-fulltext-search/Operation:Populate/Title' => 'Global search management',
	'combodo-fulltext-search/Operation:Refresh/Title' => 'Global search management',
	'FulltextSearch:Result' => 'Result',
	'FulltextSearch:PopulateResult' => 'Populate Database: %1$d entries in %2$ds (%3$d index/s)',
	'FulltextSearch:RefreshResult' => 'Rebuild Fulltext Index: %1$d entries in %2$ds (%3$d index/s)',
	'FulltextSearch:ResultCount' => '%1$d results (%2$.3f seconds)',
	'FulltextSearch:Admin' => 'Administration',
	'FulltextSearch:Score' => 'Score',
	'FulltextSearch:Class' => 'Class',
	'FulltextSearch:Org' => 'Org',
	'FulltextSearch:Previous' => 'Previous',
    'FulltextSearch:Next' => 'Next',
    'FulltextSearch:Debug' => 'Debug',
    'FulltextSearch:MatchingEntries' => 'Matching fields',
    'FulltextSearch:OpenAllMatchingEntries' => 'Open all matching fields',
    'FulltextSearch:CloseAllMatchingEntries' => 'Close all matching fields',
	'FulltextSearch:IndexOutOfDate' => 'Search index is out of date, the results may be inaccurate.',
	'FulltextSearch:IndexingTooLong' => 'The update of the global search is incomplete, it will be completed by the background task.<br/>
It is possible to <a href="%2$s">update global search now</a> (entries: %3$d, estimated time: %1$d s)',
	'FulltextSearch:ClassList' => 'Class list',
	'FulltextSearch:NoRebuildFullIndex' => 'Search index is not rebuilt with background task',
	'FulltextSearch:WeekDaysRebuildFullIndex' => 'Search index will be rebuilt every %1$s at %2$s',
	'FulltextSearch:EmptyDatabase' => 'The search database is empty',
	'FulltextSearch:PopulateDatabase' => 'Initialize search database',
	'FulltextSearch:RelatedObjectsLink' => 'Related objects',
	'FulltextSearch:RelatedByClass' => '%2$s: %1$d',
	'FulltextSearch:RelatedToTitle' => 'Objects related to the %1$s %2$s',
	'FulltextSearch:ViewResults' => 'Explore the results',

	'FulltextSearch:Status' => 'Search index status',
	'FulltextSearch:IndexEntries:Label' => 'Total search index entries',
	'FulltextSearch:IndexPendingEntries:Label' => 'Out of date search index entries',
	'FulltextSearch:IndexRebuildEntries:Label' => 'Search index entries to rebuild',
	'FulltextSearch:IndexBuildEntries:Label' => 'Search index entries to add',
	'FulltextSearch:Reindex' => 'Re-Index actions',
	'FulltextSearch:EraseIndex:Label' => 'Erase search index',
	'FulltextSearch:EraseIndexChecked:Description' => 'Warning: The global search won\'t work until the index is rebuilt',
	'FulltextSearch:RebuildIndex:Label' => 'Rebuild the search index',
	'FulltextSearch:RebuildIndexChecked:Description' => 'The Search index will be completely rebuilt',
	'FulltextSearch:RebuildIndexNotChecked:Description' => 'Only dirty entries will be rebuilt',
	'FulltextSearch:BackgroundReIndex:Label' => 'Re-Index process in background task',
	'FulltextSearch:BackgroundModeChecked:Description' => 'Background index process: The impact of re-indexation on the server will be less important, but the process will take longer',
	'FulltextSearch:BackgroundModeNotChecked:Description' => 'Foreground index process: The impact of re-indexation on the server will be important, but the search index will be ready sooner',
	'FulltextSearch:ReIndexation:Elapsed' => 'Re-index action took %1$ds',
	'FulltextSearch:ReindexAction' => 'Launch Search Re-Index',
	'FulltextSearch:NextClassToIndex:Label' => 'Class currently indexed',
));
