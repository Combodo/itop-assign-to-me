<?php
/**
 *
 * @copyright   Copyright (C) 2010-2019 Combodo SARL
 * @license     https://www.combodo.com/documentation/combodo-software-license.html
 *
 */

Dict::Add('JA JP', 'Japanese', '日本語', array(
	// Dictionary entries go here
	'FulltextSearch:Result' => 'Result~~',
	'FulltextSearch:ResultCount' => '%1$d results (%2$.3f seconds)~~',
	'FulltextSearch:Score' => 'Score~~',
	'FulltextSearch:Class' => 'Class~~',
	'FulltextSearch:Org' => 'Org~~',
	'FulltextSearch:Previous' => 'Previous~~',
    'FulltextSearch:Next' => 'Next~~',
    'FulltextSearch:Debug' => 'Debug~~',
    'FulltextSearch:MatchingEntries' => 'Matching fields~~',
    'FulltextSearch:OpenAllMatchingEntries' => 'Open all matching fields~~',
    'FulltextSearch:CloseAllMatchingEntries' => 'Close all matching fields~~',
	'FulltextSearch:AdminSearchTitle' => 'Global search management~~',
	'FulltextSearch:AdminPopulateIndex' => 'Build entire search index~~',
	'FulltextSearch:AdminPopulateIndexAction' => 'Build the search index~~',
	'FulltextSearch:AdminRefreshIndex' => 'Re-index out of date search indexes (%1$d entries)~~',
	'FulltextSearch:IndexOutOfDate' => 'Search index is out of date, the results may be inaccurate.~~',
	'FulltextSearch:IndexingTooLong' => 'The update of the global search is incomplete, it will be completed by the background task.<br/>
It is possible to <a href="%2$s">update global search now</a> (entries: %3$d, estimated time: %1$d s)~~',
	'FulltextSearch:ClassList' => 'Class list~~',

	'FulltextSearch:EmptyDatabase' => 'The search database is empty~~',
	'FulltextSearch:PopulateDatabase' => 'Initialize search database~~',
	'FulltextSearch:RelatedObjectsLink' => 'Related objects~~',
	'FulltextSearch:RelatedObjectsTitle' => 'Related objects~~',
	'FulltextSearch:RelatedByClass' => '%2$s: %1$d~~',
	'FulltextSearch:RelatedToTitle' => 'Objects related to the %1$s %2$s~~',
	'FulltextSearch:ClassRelatedToTitle' => 'Objects of class %3$s related to the %1$s %2$s~~',
	'FulltextSearch:ViewResults' => 'Explore the results~~',
));
