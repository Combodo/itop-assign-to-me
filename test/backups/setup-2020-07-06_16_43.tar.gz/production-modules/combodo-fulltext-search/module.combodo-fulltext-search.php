<?php
/**
 *
 * @copyright   Copyright (C) 2010-2019 Combodo SARL
 * @license     https://www.combodo.com/documentation/combodo-software-license.html
 *
 */

//
// iTop module definition file
//

use Combodo\iTop\FullTextSearch\Service\FullTextSearch;

SetupWebPage::AddModule(
	__FILE__, // Path to the current file, all other file names are relative to the directory containing this file
	'combodo-fulltext-search/1.0.13',
	array(
		// Identification
		//
		'label' => 'Enhanced global search',
		'category' => 'business',

		// Setup
		//
		'dependencies' => array(
		),
		'mandatory' => false,
		'visible' => true,
		'installer' => 'FulltextSearchInstaller',

		// Components
		//
		'datamodel' => array(
			'src/Controller/FullTextController.php',
			'src/Controller/FullTextAdminController.php',
			'src/Controller/FullTextAjaxController.php',
			'src/Service/FullTextUtils.php',
			'src/Service/MemoryKpi.php',
			'src/Service/MemoryKpiLog.php',
			'src/Service/FullTextIndexer.php',
			'src/Service/FullTextSearch.php',
			'main.combodo-fulltext-search.php',
			'model.combodo-fulltext-search.php',
			'fulltext-background-refresh.class.php',
		),
		'webservice' => array(),
		'data.struct' => array(// add your 'structure' definition XML files here,
		),
		'data.sample' => array(// add your sample data XML files here,
		),

		// Documentation
		//
		'doc.manual_setup' => '', // hyperlink to manual setup documentation, if any
		'doc.more_information' => '', // hyperlink to more information, if any 

		// Default settings
		//
		'settings' => array(// Module specific settings go here, if any
			// see datamodel <module_parameters>
		),
	)
);

if (!class_exists('FulltextSearchInstaller'))
{
// Module installation handler
//
	class FulltextSearchInstaller extends ModuleInstallerAPI
	{
		public static function AfterDatabaseCreation(Config $oConfiguration, $sPreviousVersion, $sCurrentVersion)
		{
            SetupPage::log_info("AfterDatabaseCreation Indexation FullTextSearch");
            FullTextSearch::$bSetupMode = true;
			FullTextSearch::CreateFullTextTable();
		}

		/**
		 * Automatic database indexation at setup is removed.
		 * Need to run populate_search.php to index the database.
		 *
		 * @param \Config $oConfiguration
		 * @param $sPreviousVersion
		 * @param $sCurrentVersion
		 */
		public static function AfterDataLoad(Config $oConfiguration, $sPreviousVersion, $sCurrentVersion)
		{
            FullTextSearch::$bSetupMode = false;
        }
	}
}

