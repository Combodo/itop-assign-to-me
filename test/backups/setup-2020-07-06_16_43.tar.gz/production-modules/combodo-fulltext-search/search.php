<?php
/**
 *
 * @copyright   Copyright (C) 2010-2019 Combodo SARL
 * @license     https://www.combodo.com/documentation/combodo-software-license.html
 *
 */

namespace Combodo\iTop\FullTextSearch;

use Combodo\iTop\FullTextSearch\Service\FullTextUtils;
use utils;

require_once('../../approot.inc.php');
require_once(APPROOT.'application/application.inc.php');
require_once(APPROOT.'application/itopwebpage.class.inc.php');
require_once(APPROOT.'application/startup.inc.php');
require_once(APPROOT.'application/loginwebpage.class.inc.php');

/////////////////////////////////////////////////////////////////////
// Main program
//
//LoginWebPage::DoLogin(); // Check user rights and prompt if needed

$sFullText = trim(utils::ReadParam('text', '', false, 'raw_data'));
$sStartPage = utils::GetAbsoluteUrlModulePage(FullTextUtils::GetModuleName(), 'index.php').'&operation=Search&text='.urlencode($sFullText);
header("Location: $sStartPage");
