<?php
/**
 *
 * @copyright   Copyright (C) 2010-2019 Combodo SARL
 * @license     https://www.combodo.com/documentation/combodo-software-license.html
 *
 */


namespace Combodo\iTop\FullTextSearch;

use Combodo\iTop\FullTextSearch\Controller\FullTextAjaxController;
use Combodo\iTop\FullTextSearch\Service\FullTextUtils;

require_once(APPROOT.'application/startup.inc.php');

$sModuleName = FullTextUtils::GetModuleName();
$oUpdateController = new FullTextAjaxController(MODULESROOT.$sModuleName.'/view/admin', $sModuleName);
$oUpdateController->AllowOnlyAdmin();
// Allow parallel execution of ajax requests
session_write_close();
$oUpdateController->HandleAjaxOperation();

