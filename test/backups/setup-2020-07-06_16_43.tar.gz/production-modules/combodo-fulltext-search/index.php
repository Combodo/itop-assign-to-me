<?php
/**
 * @copyright   Copyright (C) 2010-2020 Combodo SARL
 * @license     http://opensource.org/licenses/AGPL-3.0
 */

namespace Combodo\iTop\FullTextSearch;

use Combodo\iTop\FullTextSearch\Controller\FullTextController;
use Combodo\iTop\FullTextSearch\Service\FullTextUtils;

require_once(APPROOT.'application/startup.inc.php');

$sModuleName = FullTextUtils::GetModuleName();
$oUpdateController = new FullTextController(MODULESROOT.$sModuleName.'/view', $sModuleName);
$oUpdateController->SetDefaultOperation('Search');
$oUpdateController->HandleOperation();
