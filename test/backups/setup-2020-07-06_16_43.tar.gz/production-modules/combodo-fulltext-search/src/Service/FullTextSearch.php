<?php
/**
 *
 * @copyright   Copyright (C) 2010-2019 Combodo SARL
 * @license     https://www.combodo.com/documentation/combodo-software-license.html
 *
 */

namespace Combodo\iTop\FullTextSearch\Service;

use BinaryExpression;
use CMDBSource;
use CoreException;
use DBObjectSearch;
use DBObjectSet;
use DBSearch;
use Exception;
use FieldExpression;
use IssueLog;
use MetaModel;
use MySQLException;
use User;
use UserRights;
use UserRightsProfile;
use utils;
use VariableExpression;


/**
 * Fulltext Global Search API
 *
 * Created by PhpStorm.
 * User: Eric
 * Date: 08/11/2017
 * Time: 11:25
 */
class FullTextSearch extends FullTextIndexer
{
    /**
     * Count related objects (objects that link to the given object)
     *
     * @param string $sClass Object class name
     * @param string $sId Key of the object
     *
     * @return array of number of related objects
     */
	public static function CountRelatedObjects($sClass, $sId)
	{
		$aRelatedObjects = array();
		self::BuildExternalKeyLinks();
		$aClassLinks = self::$aClassExternalKeyLinks;

		if (!empty($aClassLinks[$sClass]))
		{
			foreach($aClassLinks[$sClass] as $sLinkedClass => $aAttCodes)
			{
				try
				{
					$sOQL = 'SELECT '.$sLinkedClass.' WHERE '.implode(' = :id OR ',
							array_keys($aAttCodes)).' = :id';
					$oSearch = DBObjectSearch::FromOQL($sOQL);
					$oSet = new DBObjectSet($oSearch, array(), array('id' => $sId));
					$iCount = $oSet->Count();
					if ($iCount > 0)
					{
						$aRelatedObjects[$sLinkedClass] = $iCount;
					}
				}
				catch (Exception $e)
				{
					IssueLog::Error($e->getMessage());
				}
			}
		}
		$aIndirectClassLinks = self::$aClassIndirectLinks;
		if (!empty($aIndirectClassLinks[$sClass]))
		{
			foreach ($aIndirectClassLinks[$sClass] as $sLnkClass => $aExtKeyToRemote)
			{
				foreach ($aExtKeyToRemote as $sExtKeyToRemote => $aLinkedClasses)
				{
					foreach ($aLinkedClasses as $sLinkedClass => $sExtKeyToMe)
					{
						try
						{
							$sOQL = "SELECT {$sLinkedClass} JOIN {$sLnkClass} ON {$sLnkClass}.{$sExtKeyToMe} = {$sLinkedClass}.id WHERE {$sLnkClass}.{$sExtKeyToRemote} = :id";
							$oSearch = DBObjectSearch::FromOQL($sOQL);
							$oSet = new DBObjectSet($oSearch, array(), array('id' => $sId));
							$iCount = $oSet->Count();
							if ($iCount > 0)
							{
								if (isset($aRelatedObjects[$sLinkedClass]))
								{
									$iCount += $aRelatedObjects[$sLinkedClass];
								}
								$aRelatedObjects[$sLinkedClass] = $iCount;
							}
						} catch (Exception $e)
						{
							IssueLog::Error($e->getMessage());
						}
					}
				}
			}
		}
		return $aRelatedObjects;
	}

	public static function GetRelatedObjectsFilter($sClass, $sId, $sLinkClass)
	{
		self::BuildExternalKeyLinks();
		$aClassLinks = self::$aClassExternalKeyLinks;

		$sOQL = '';
		if (!empty($aClassLinks[$sClass]) && isset($aClassLinks[$sClass][$sLinkClass]))
		{
			$aAttCodes = $aClassLinks[$sClass][$sLinkClass];
			$sOQL = "SELECT {$sLinkClass} WHERE ".implode(" = {$sId} OR ",
					array_keys($aAttCodes))." = {$sId}";
		}

		$aIndirectClassLinks = self::$aClassIndirectLinks;
		if (!empty($aIndirectClassLinks[$sClass]))
		{
			foreach ($aIndirectClassLinks[$sClass] as $sLnkClass => $aExtKeyToRemote)
			{
				foreach ($aExtKeyToRemote as $sExtKeyToRemote => $aLinkedClasses)
				{
					if (isset($aLinkedClasses[$sLinkClass]))
					{
						$sExtKeyToMe = $aLinkedClasses[$sLinkClass];
						if (!empty($sOQL))
						{
							$sOQL .= ' UNION ';
						}
						$sOQL .= "SELECT {$sLinkClass} JOIN {$sLnkClass} ON {$sLnkClass}.{$sExtKeyToMe} = {$sLinkClass}.id WHERE {$sLnkClass}.{$sExtKeyToRemote} = {$sId}";
					}
				}
			}
		}

		if (!empty($sOQL))
		{
			try
			{
				$oSearch = DBSearch::FromOQL($sOQL);
				return $oSearch->Serialize();
			}
			catch (Exception $e)
			{
				IssueLog::Error($e->getMessage());
			}
		}
		return '';
	}

	/**
	 * Count the entries in the fulltext database table
	 *
	 * @param int $iLimit
	 *
	 * @return int The number of entries in the fulltext database table
	 */
	public static function TotalSearchEntries($iLimit = 0)
	{
		$sTableName = self::GetIndexTableName();
		if ($iLimit > 0)
		{
			$sCountQuery = "SELECT COUNT(*) FROM (SELECT id FROM {$sTableName} WHERE 1 LIMIT {$iLimit}) AS __count__";
		}
		else
		{
			$sCountQuery = "SELECT COUNT(*) FROM {$sTableName} WHERE 1";
		}
		try
		{
			$iCount = CMDBSource::QueryToScalar($sCountQuery);

			/** @var int $iCount */
			return $iCount;
		}
		catch (MySQLException $e)
		{
			IssueLog::Error($e->getMessage());
			return 0;
		}
	}

	public static function IsSearchableClass($sClass)
	{
		return in_array($sClass, self::GetSearchableClasses());
	}

	/**
	 * Search the fulltext database table
	 *
	 * @param string $sNeedle List of words to be searched. can be in the form classname:needle
	 * @param int $iLimit Max number of results returned
	 * @param int $iOffset Offset of the returned list
	 *
	 * @return array List of (obj_class, obj_key, friendlyname) returned by the search.
	 * @throws \Exception
	 */
	public static function Search($sNeedle, $iLimit = 15, $iOffset = 0)
	{
		$aParams = self::GetSearchParams($sNeedle);

		if (empty($aParams)) { return array(); }

		$aParams['limit_filter'] = self::GetLimitFilter($iLimit, $iOffset);
        $aParams['sentence_weight_factor'] = MetaModel::GetModuleSetting(FullTextUtils::GetModuleName(), 'sentence_weight_factor', 10);
        $aParams['mandatory_weight_factor'] = MetaModel::GetModuleSetting(FullTextUtils::GetModuleName(), 'mandatory_weight_factor', 2);
        $aParams['start_with_weight_factor'] = MetaModel::GetModuleSetting(FullTextUtils::GetModuleName(), 'start_with_weight_factor', 0.5);

		$aResults = array();

		$sReq = self::GetSelectRequest($aParams);
		try
		{
			$aResults = CMDBSource::QueryToArray($sReq);
		}
		catch (MySQLException $e)
		{
			IssueLog::Error($e->getMessage());
		}

		return $aResults;
	}

	/**
	 * Count the entries corresponding to the given needle in the fulltext database table
	 *
	 * @param string $sNeedle List of words to be searched. can be in the form classname:needle
	 *
	 * @return integer
	 * @throws \CoreException
	 * @throws \Exception
	 */
	public static function Count($sNeedle)
	{
		$aParams = self::GetSearchParams($sNeedle);

		if (empty($aParams)) { return 0; }

		$iCount = 0;
		$sReq = self::GetCountRequest($aParams);
		try
		{
			$resQuery = CMDBSource::Query($sReq);
			if (!$resQuery) { return 0; }

			$aRow = CMDBSource::FetchArray($resQuery);
			CMDBSource::FreeResult($resQuery);
			$iCount = intval($aRow['COUNT']);
		}
		catch (MySQLException $e)
		{
			IssueLog::Error($e->getMessage());
		}

		return $iCount;
	}

	/**
	 * Get the result count grouped by classes
	 *
	 * @param $sNeedle
	 *
	 * @return array of ('class', 'count')
	 * @throws \Exception
	 */
	public static function CountGroupByClasses($sNeedle)
	{
		$aParams = self::GetSearchParams($sNeedle);

		if (empty($aParams)) { return array(); }

		$aResults = array();
		$sReq = self::GetGroupByClassesRequest($aParams);
		try
		{
			$aRows = CMDBSource::QueryToArray($sReq);
			foreach($aRows as $aRow)
			{
				$iCount = intval($aRow['_itop_count']);
				$sClass = $aRow['obj_class'];
				$aResults[] = array('class' => $sClass, 'count' => $iCount);
			}
		}
		catch (MySQLException $e)
		{
			IssueLog::Error($e->getMessage());
		}

		return $aResults;
	}

	protected static function GetLimitFilter($iLimit, $iOffset)
	{
		if ($iLimit > 0)
		{
			$sLimitFilter = ' LIMIT '.$iOffset.', '.$iLimit;
		}
		else
		{
			$sLimitFilter = '';
		}
		return $sLimitFilter;
	}

	/**
	 * @param $sNeedle
	 *
	 * @return array
	 * @throws \Exception
	 */
	public static function GetSearchParams($sNeedle)
	{
		$aParams = array();
		$sNeedle = self::SanitizeValue($sNeedle);
        $sNeedle = self::ExtractClassName($sNeedle, $aParams);
        $sClassName = $aParams['class_name'];

        $aSearchClasses = array();
		if (!empty($sClassName))
		{
			try
			{
				$aSearchClasses = MetaModel::EnumChildClasses($sClassName, ENUM_CHILD_CLASSES_ALL);
			}
			catch (CoreException $e)
			{
				IssueLog::Error($e->getMessage());
			}
		}

		if (empty($aSearchClasses))
		{
			$aSearchClasses = self::GetSearchableClasses();
		}

		// Access Rights in case of UserRightsProfile
		$oRights = UserRights::GetModuleInstance();
		$sOrgFilter = '';
		if ($oRights instanceof UserRightsProfile)
		{
			$oRights->LoadCache();
			$oUser = UserRights::GetUserObject();
			if (!is_null($oUser) && !$oRights->IsAdministrator($oUser))
			{
				// Remove non-allowed classes
				foreach($aSearchClasses as $index => $sClass)
				{
					$aObjectPermissions = self::GetUserActionGrant($oRights, $oUser, $sClass);
					if ($aObjectPermissions['permission'] == UR_ALLOWED_NO)
					{
						unset($aSearchClasses[$index]);
					}
				}

				// Get the list of allowed organizations
				$aUserOrgs = self::GetUserOrgs($oUser);
				if (count($aUserOrgs) !== 0)
				{
					$sOrgFilter = ' AND s.org_id IN ('.implode(',', $aUserOrgs).')';
				}
			}
		}
		$aParams['org_filter'] = $sOrgFilter;

		if (empty($aSearchClasses))
		{
			// No class allowed => no result
			return array();
		}
		else
		{
			$sClassNameList = "'".implode("','", $aSearchClasses)."'";
			$aParams['class_filter'] = ' AND s.obj_class IN ('.$sClassNameList.')';
		}

		// Check id first
		if (is_numeric($sNeedle))
		{
			$aParams['id_filter'] = ' OR s.obj_key = '.$sNeedle;
		}
		else
		{
			$aParams['id_filter'] = '';
		}

		$sVisibilityFilter = '';
		if (!utils::ShowObsoleteData())
		{
			$sVisibilityFilter .= ' AND s.obsolescence_flag = 0';
		}
		if (!utils::IsArchiveMode())
		{
			$sVisibilityFilter .= ' AND s.archive_flag = 0';
		}
		$aParams['visibility_filter'] = $sVisibilityFilter;

		$aParams['mode'] = 'IN BOOLEAN MODE';

        $aParams['needle_plus'] = preg_replace('#((?<=\s)\w{3}|^\w{3})#u', '+$1', $sNeedle);
        $aParams['needle_more'] = self::GetNeedleForWordOrder($sNeedle);
        $aParams['needle_highlight'] = self::GetNeedleForHighlight($sNeedle);


		return $aParams;
	}

    /**
     * @param $sNeedle
     * @param $aParams
     *
     * @return string
     */
    protected static function ExtractClassName($sNeedle, &$aParams)
    {
        // Check if a class name/label is supplied to limit the search
        $sClassName = '';
        $sSearchClassName = '';
        if (preg_match('/^([^\":]+):(.+)$/', $sNeedle, $aMatches))
        {
            $sSearchClassName = $aMatches[1];
            try
            {
                if (MetaModel::IsValidClass($sSearchClassName))
                {
                    $sNeedle = trim($aMatches[2]);
                    $sClassName = $sSearchClassName;
                }
                elseif ($sClassName = MetaModel::GetClassFromLabel($sSearchClassName, false /* => not case sensitive */))
                {
                    $sNeedle = trim($aMatches[2]);
                }
                else
                {
                    $sSearchClassName = '';
                }
            } catch (Exception $e)
            {
                IssueLog::Error($e->getMessage());
                $sSearchClassName = '';
            }
        }
        $aParams['class_name'] = $sClassName;
        $aParams['search_class_name'] = $sSearchClassName;
        $aParams['needle'] = $sNeedle;

        return $sNeedle;
    }

    /**
     * @param string $sText
     * @param string $sSearch
     * @param int $iMaxWords
     *
     * @return string|false return false if no match or the modified string
     */
    public static function GetHighlight($sText, $sSearch, $iMaxWords = 0)
    {
        $sResult = $sText;
        $aParams = array();
        $sSearch = FullTextSearch::ExtractClassName($sSearch, $aParams);
        $sSearch = FullTextIndexer::SanitizeMySQLChars($sSearch);
        $sResult = preg_replace("|(\b{$sSearch}\b)|iu", '__start__em__$1__end__em__', $sResult);
        if ($sText === $sResult)
        {
            $aWords = explode(' ', $sSearch);
            foreach($aWords as $sWord)
            {
                if (strlen($sWord) > 2)
                {
                    if (count($aWords) == 1)
                    {
                        $sResult = preg_replace("|(\b{$sWord}\w*\b)|iu", '__start__em__$1__end__em__', $sResult);

                    }
                    else
                    {
                        $sResult = preg_replace("|(\b{$sWord}\b)|iu", '__start__em__$1__end__em__', $sResult);
                    }
                }
            }
        }

        if ($sText === $sResult)
        {
            return false;
        }

        if ($iMaxWords > 0)
        {
            $aResultWords = explode(' ', $sResult);
            if (count($aResultWords) > $iMaxWords)
            {
                for($i = 0; $i < count($aResultWords); $i++)
                {
                    if (strpos($aResultWords[$i], '__start__em__') !== false)
                    {
                        $iStart = (int)max(0, $i - $iMaxWords / 2);
                        $iLength = (int)min(count($aResultWords) - 1 - $iStart, $iMaxWords);
                        $aResultWords = array_slice($aResultWords, $iStart, $iLength);
                        $sResult = implode(' ', $aResultWords);
                    }
                }
            }
        }
        $sResult = htmlentities($sResult, ENT_QUOTES, 'UTF-8');
        $sResult = str_replace('__start__em__', '<span class="fulltext-em">', $sResult);
        $sResult = str_replace('__end__em__', '</span>', $sResult);
        return $sResult;
    }

    /**
     * @param $aParams
     *
     * @return string
     */
	protected static function GetSelectRequest($aParams)
	{
		$sTableName = self::GetIndexTableName();
		$sTablePrefix = self::GetTablePrefix();
		if (strpos($aParams['needle_more'], ' ') === false)
        {
            $fMoreFactor = $aParams['start_with_weight_factor'];
        }
        else
        {
            $fMoreFactor = $aParams['sentence_weight_factor'];
        }

		return <<<SQL
SELECT DISTINCT s.obj_class as obj_class, s.obj_key as obj_key, s.friendlyname as friendlyname, s.org_id as org_id, org.name as org_name,
 (MATCH (s._detail) AGAINST ('{$aParams['needle_plus']}' {$aParams['mode']}) * {$aParams['mandatory_weight_factor']}) as cpt_plus,
 (MATCH (s._detail) AGAINST ('{$aParams['needle_more']}' {$aParams['mode']}) * {$fMoreFactor}) as cpt_more,
  MATCH (s._detail) AGAINST ('{$aParams['needle']}' {$aParams['mode']}) as cpt_main,
  s.obj_weight as cpt_class,
 ((MATCH (s._detail) AGAINST ('{$aParams['needle_plus']}' {$aParams['mode']}) * {$aParams['mandatory_weight_factor']})
  + (MATCH (s._detail) AGAINST ('{$aParams['needle_more']}' {$aParams['mode']}) * {$fMoreFactor})
   + MATCH (s._detail) AGAINST ('{$aParams['needle']}' {$aParams['mode']}))
    * s.obj_weight AS cpt
 FROM {$sTableName} s
 LEFT JOIN {$sTablePrefix}organization org ON org.id = s.org_id
 WHERE (MATCH (s._detail) AGAINST ('{$aParams['needle']}' {$aParams['mode']}) {$aParams['id_filter']}
  OR MATCH (s._detail) AGAINST ('{$aParams['needle_more']}' {$aParams['mode']})
  OR MATCH (s._detail) AGAINST ('{$aParams['needle_plus']}' {$aParams['mode']}))
 {$aParams['class_filter']}
 {$aParams['visibility_filter']}
 {$aParams['org_filter']}
 ORDER BY cpt DESC, friendlyname ASC
 {$aParams['limit_filter']}
SQL;
	}

    /**
     * @param $aParams
     *
     * @return string
     */
	protected static function GetGroupByClassesRequest($aParams)
	{
		$sTableName = self::GetIndexTableName();

		return <<<EOF
SELECT DISTINCT s.obj_class as obj_class, COUNT(*) as _itop_count
 FROM {$sTableName} s
 WHERE (MATCH (s._detail) AGAINST ('{$aParams['needle']}' {$aParams['mode']}) {$aParams['id_filter']}
  OR MATCH (s._detail) AGAINST ('{$aParams['needle_more']}' {$aParams['mode']})
   OR MATCH (s._detail) AGAINST ('{$aParams['needle']}' {$aParams['mode']}))
 {$aParams['class_filter']}
 {$aParams['visibility_filter']}
 {$aParams['org_filter']}
 GROUP BY s.obj_class
EOF;
    }

    /**
     * @param $aParams
     * @return string
     */
	protected static function GetCountRequest($aParams)
	{
		$sTableName = self::GetIndexTableName();

		return <<<EOF
SELECT COUNT(DISTINCT s.id) as COUNT FROM {$sTableName} s
 WHERE (MATCH (s._detail) AGAINST ('{$aParams['needle']}' {$aParams['mode']}) {$aParams['id_filter']}
  OR MATCH (s._detail) AGAINST ('{$aParams['needle_more']}' {$aParams['mode']})
   OR MATCH (s._detail) AGAINST ('{$aParams['needle']}' {$aParams['mode']}))
 {$aParams['class_filter']}
 {$aParams['visibility_filter']}
 {$aParams['org_filter']}
EOF;
	}

	protected static $m_aUserOrgs = array();

	/**
	 * Read and cache organizations allowed to the given user
	 *
	 * Copied from UserRightsProfile (protected)
	 *
	 * @param User oUser
	 *
	 * @return mixed
	 * @throws \Exception
	 */
	protected static function GetUserOrgs($oUser)
	{
		$iUser = $oUser->GetKey();
		if (!array_key_exists($iUser, self::$m_aUserOrgs))
		{
			self::$m_aUserOrgs[$iUser] = array();

			try
			{
				$sHierarchicalKeyCode = MetaModel::IsHierarchicalClass('Organization');
				if ($sHierarchicalKeyCode !== false)
				{
					$sUserOrgQuery = 'SELECT Org FROM Organization AS Org JOIN Organization AS Root ON Org.'.$sHierarchicalKeyCode.' BELOW Root.id JOIN URP_UserOrg AS UserOrg ON UserOrg.allowed_org_id = Root.id WHERE UserOrg.userid = :userid';
					$oUserOrgSet = new DBObjectSet(DBObjectSearch::FromOQL_AllData($sUserOrgQuery), array(),
						array('userid' => $iUser));
					while ($aRow = $oUserOrgSet->FetchAssoc())
					{
						$oOrg = $aRow['Org'];
						self::$m_aUserOrgs[$iUser][] = $oOrg->GetKey();
					}
				}
				else
				{
					try
					{
						$oSearch = new DBObjectSearch('URP_UserOrg');
						$oSearch->AllowAllData();
						$oCondition = new BinaryExpression(new FieldExpression('userid'), '=',
							new VariableExpression('userid'));
						$oSearch->AddConditionExpression($oCondition);

						$oUserOrgSet = new DBObjectSet($oSearch, array(), array('userid' => $iUser));
						while ($oUserOrg = $oUserOrgSet->Fetch())
						{
							self::$m_aUserOrgs[$iUser][] = $oUserOrg->Get('allowed_org_id');
						}
					}
					catch (Exception $e)
					{
						IssueLog::Error($e->getMessage());
					}
				}
			}
			catch (CoreException $e)
			{
				IssueLog::Error($e->getMessage());
			}

		}

		return self::$m_aUserOrgs[$iUser];
	}

	static $m_aObjectActionGrants = array();

	/**
	 * Get the access rights to the specified class
	 *
	 * Copied from UserRightsProfile (protected)
	 *
	 * @param UserRightsProfile $oRights
	 * @param User $oUser
	 * @param string $sClass
	 *
	 * @return array Permissions
	 */
	protected static function GetUserActionGrant($oRights, $oUser, $sClass)
	{
		$oRights->LoadCache();

		// load and cache permissions for the current user on the given class
		//
		$iUser = $oUser->GetKey();
		$aTest = @self::$m_aObjectActionGrants[$iUser][$sClass][UR_ACTION_READ];
		if (is_array($aTest))
		{
			return $aTest;
		}

		$sAction = UserRightsProfile::$m_aActionCodes[UR_ACTION_READ];

		$bStatus = null;
		// Call the API of UserRights because it caches the list for us
		foreach(UserRights::ListProfiles($oUser) as $iProfile => $oProfile)
		{
			$bGrant = $oRights->GetProfileActionGrant($iProfile, $sClass, $sAction);
			if (!is_null($bGrant))
			{
				if ($bGrant)
				{
					if (is_null($bStatus))
					{
						$bStatus = true;
					}
				}
				else
				{
					$bStatus = false;
				}
			}
		}

		$iPermission = $bStatus ? UR_ALLOWED_YES : UR_ALLOWED_NO;

		$aRes = array(
			'permission' => $iPermission,
		);
		self::$m_aObjectActionGrants[$iUser][$sClass][UR_ACTION_READ] = $aRes;

		return $aRes;
	}
}
