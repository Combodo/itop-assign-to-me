<?php
/**
 *
 * @copyright   Copyright (C) 2010-2019 Combodo SARL
 * @license     https://www.combodo.com/documentation/combodo-software-license.html
 *
 */

namespace Combodo\iTop\FullTextSearch\Service;

class MemoryKpiLog
{
	private static $aLog = array();
	private static $aErrorLog = array();
	private static $aKPIs = array();

	public static function SetTitle($sTitle)
	{
		self::$aLog[] = MemoryKpi::GetResultHeader($sTitle);
	}

	public static function MeasureStartPoint($sName)
	{
		if (!isset(self::$aKPIs[$sName]))
		{
			self::$aKPIs[$sName] = new MemoryKpi();
		}
		return self::$aKPIs[$sName];
	}

	public static function MeasureIntermediatePoint($sName, $sTitle)
	{
		if (!isset(self::$aKPIs[$sName])) { return; }

		$oKPI = self::$aKPIs[$sName];
		$oKPI->MeasurePoint();
		self::$aLog[] = $oKPI->GetResultLine($sTitle);
	}


	public static function MeasureEndPoint($sName, $sTitle)
	{
		if (!isset(self::$aKPIs[$sName])) { return; }

		self::MeasureIntermediatePoint($sName, $sTitle);
		unset(self::$aKPIs[$sName]);
	}

	public static function GetLog()
	{
		self::$aLog[] = MemoryKpi::GetResultFooter();
		$aLog = array_merge(self::$aErrorLog, self::$aLog);
		return $aLog;
	}

	public static function LogError($sMessage)
	{
		self::$aErrorLog[] = $sMessage;
	}

	public static function OnExit()
	{
		foreach(self::$aKPIs as $sName => $sKpi)
		{
			self::MeasureIntermediatePoint($sName, "$sName unfinished");
			unset(self::$aKPIs[$sName]);
		}
		return self::GetLog();
	}

}
