<?php
/**
 * @copyright   Copyright (C) 2010-2020 Combodo SARL
 * @license     http://opensource.org/licenses/AGPL-3.0
 */


namespace Combodo\iTop\FullTextSearch\Service;


class FullTextUtils
{

	public static function GetModuleName()
	{
		return 'combodo-fulltext-search';
	}
}
