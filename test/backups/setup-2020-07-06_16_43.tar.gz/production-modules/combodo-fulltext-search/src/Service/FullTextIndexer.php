<?php
/**
 *
 * @copyright   Copyright (C) 2010-2019 Combodo SARL
 * @license     https://www.combodo.com/documentation/combodo-software-license.html
 *
 */

namespace Combodo\iTop\FullTextSearch\Service;

use AttributeBlob;
use AttributeDefinition;
use AttributeEncryptedString;
use AttributeExternalField;
use AttributeExternalKey;
use AttributeImage;
use AttributeLinkedSetIndirect;
use AttributeOneWayPassword;
use AttributePassword;
use cmdbAbstractObject;
use CMDBSource;
use CoreException;
use DBObject;
use DBObjectSearch;
use DBObjectSet;
use DBSearch;
use Dict;
use Exception;
use ExecutionKPI;
use IssueLog;
use MetaModel;
use MySQLException;
use SetupUtils;
use UserRights;
use UserRightsProfile;
use utils;

define('POPULATE_LIMIT', 1000);
define('OPERATION_REINDEX', 'reindex');
define('OPERATION_REBUILD', 'rebuild');
define('OPERATION_BUILD', 'build');

class FullTextIndexer
{
	const INDEXATION_TIME_SLOT = 10;

	public static $bSetupMode = false;
	protected static $aClassWeight = array();
	protected static $aClassLinks = array();
	/**
	 * @var array The model big picture of the dependencies in the form
	 *      array[target_class][linking_class][link_attrcode] = true
	 */
	protected static $aClassExternalKeyLinks = array();
	/**
	 * @var array The model big picture of the indirect dependencies in the form
	 *      array[sTargetClass][sLnkClass][sExtKeyToTarget][$sClass] = $sExtKeyToMe
	 */
	protected static $aClassIndirectLinks = array();
	protected static $aActions = array();
	protected static $aDirtyObjects = array();
	protected static $aBulkInserts = array();
	protected static $iInsertBufferLength = 0;

	/**
	 * Insert an object into the fulltext database index
	 *
	 * @param DBObject $oObject Object to insert
	 * @param string $sClass class name of the object
	 */
	public static function InsertObject($oObject, $sClass)
	{
		try
		{
			if (self::$bSetupMode || $oObject->IsArchived())
			{
				return;
			}
			$aWeights = MetaModel::GetModuleSetting(FullTextUtils::GetModuleName(), 'object_weight_factor', array());
			foreach($aWeights as $sWeightedClass => $fWeight)
			{
				self::SetAClassWeight($sWeightedClass, $fWeight);
			}
			$sFriendlyName = addslashes($oObject->get('friendlyname'));
			$s_FriendlyName = self::SanitizeValue($oObject->get('friendlyname'));
			$iObsolescenceFlag = $oObject->IsObsolete() ? 1 : 0;
			$iArchivedFlag = $oObject->IsArchived() ? 1 : 0;
			$sId = $oObject->GetKey();
			$sDetail = self::GetObjectDetails($oObject, $sClass, $sFriendlyName);

			// Get the organization of the object
			$sOrgAttCode = UserRightsProfile::GetOwnerOrganizationAttCode($sClass);
			if (is_null($sOrgAttCode))
			{
				$iOrgId = 0;
			}
			else
			{
				$iOrgId = $oObject->Get($sOrgAttCode);
			}
			if (isset(self::$aClassWeight[$sClass]))
			{
				$fWeight = self::$aClassWeight[$sClass];
			}
			else
			{
				$fWeight = 1;
			}
			$sTableName = self::GetIndexTableName();

			$sInsertReq = "INSERT INTO {$sTableName} (obj_class, obj_key, org_id, obj_weight, friendlyname, _friendlyname, _detail, obsolescence_flag, archive_flag) VALUE ('{$sClass}', {$sId}, {$iOrgId}, $fWeight, '{$sFriendlyName}', '{$s_FriendlyName}', '{$sDetail}', {$iObsolescenceFlag}, $iArchivedFlag)";
			CMDBSource::Query($sInsertReq);
		}
		catch (Exception $e)
		{
			IssueLog::Error($e->getMessage());
		}
	}

	/**
	 * Delete an object from the fulltext database index
	 *
	 * @param DBObject $oObject object to delete
	 */
	public static function DeleteObject($oObject)
	{
		try
		{
			$sClass = get_class($oObject);
			$sId = $oObject->GetKey();
			self::DeleteIndex($sClass, $sId);
		}
		catch (Exception $e)
		{
			IssueLog::Error($e->getMessage());
		}
	}

	protected static function DeleteIndex($sClass, $sId)
	{
		try
		{
			$sTableName = self::GetIndexTableName();
			$sDeleteReq = "DELETE FROM {$sTableName} WHERE obj_class='{$sClass}' AND obj_key={$sId}";
			CMDBSource::Query($sDeleteReq);
		}
		catch (Exception $e)
		{
			IssueLog::Error($e->getMessage());
		}
	}

	/**
	 * Reindex an object in the fulltext database
	 *
	 * @param DBObject $oObject object to reindex
	 * @param string $sClass class name of the object to reinject
	 * @param array $aChangedAttCodes List of all the changed attributes code for this update
	 * @param int $iMaxTime
	 *
	 * @throws \Exception
	 */
	public static function UpdateObject($oObject, $sClass, $aChangedAttCodes, $iMaxTime = 0)
	{
		if (self::$bSetupMode || !is_array($aChangedAttCodes))
		{
			return;
		}
		self::ReIndexObject($sClass, $oObject->GetKey());

		// Plan for reindexing the entries
		self::$aActions = array();
		self::$aDirtyObjects = array();
		if (in_array('friendlyname', $aChangedAttCodes))
		{
			// Need to reindex all the objects pointing to this object using an external key
			self::PlanForReindexingExternalKeys($sClass, $oObject->GetKey());
		}
		self::PlanForReindexingFriendlyname($sClass, $oObject->GetKey(), $aChangedAttCodes);
		self::$aActions = array_reverse(self::$aActions);

		$fRate = 250;
		if (($iMaxTime == 0) || (time() < $iMaxTime))
		{
			$iCount = 0;
			// try to reindex during the remaining time
			while ($aAction = array_pop(self::$aActions))
			{
				list($sObjClass, $sObjKey) = $aAction;
				self::ReIndexObject($sObjClass, $sObjKey);
				$iCount++;
				if (($iMaxTime > 0) && (time() > $iMaxTime))
				{
					// timeout just save the remaining actions
					break;
				}
			}
		}
		if (count(self::$aActions) > 0)
		{
			if (UserRights::IsAdministrator())
			{
				$sHref = utils::GetAbsoluteUrlModulePage(FullTextUtils::GetModuleName(), 'index-admin.php').'&operation=Refresh';
				$iRemaining = count(self::$aActions);
				$fTime = $iRemaining / $fRate;
				$iTime = intval($fTime);
				$sMessage = Dict::Format('FulltextSearch:IndexingTooLong', $iTime, $sHref, $iRemaining);
				cmdbAbstractObject::SetSessionMessage($sClass, $oObject->GetKey(), 'update_index', $sMessage, 'info', 1000);
			}
			self::InsertAllActions();
		}
	}

	protected static function PlanForReindexingExternalKeys($sClass, $sId)
	{
		// Need to reindex all the objects pointing to this object using an external key
		self::BuildExternalKeyLinks();
		$aClassLinks = self::$aClassExternalKeyLinks;
		if (!empty($aClassLinks[$sClass]))
		{
			foreach($aClassLinks[$sClass] as $sLinkedClass => $aAttCodes)
			{
				try
				{
					$sOQL = "SELECT $sLinkedClass WHERE ".implode(" = $sId UNION SELECT $sLinkedClass WHERE ", array_keys($aAttCodes)).' = '.$sId;
					$oSearch = DBObjectSearch::FromOQL($sOQL);
					$oSearch->AllowAllData();
					$sAliasClass = $oSearch->GetClassAlias();
					$oSet = new DBObjectSet($oSearch);
					$oSet->OptimizeColumnLoad(array($sAliasClass => array()));
					$oSet->Rewind();
					while ($oLinkedObject = $oSet->Fetch())
					{
						self::AddAction($sLinkedClass, $oLinkedObject->GetKey(), OPERATION_REINDEX);
					}
				}
				catch (Exception $e)
				{
					IssueLog::Error($e->getMessage());
				}
			}
		}
	}

	protected static function PlanForReindexingFriendlyname($sClass, $sId, $aChangedAttCodes)
	{
		// Need to reindex all the objects pointing to this object using an external key
		$aClassLinks = self::GetFriendlynameLinks();
		if (!empty($aClassLinks[$sClass]))
		{
			foreach($aClassLinks[$sClass] as $sLinkedClass => $aConcernedAttCodes)
			{
				$aAttCodes = array();
				foreach($aConcernedAttCodes as $sAttCode)
				{
					if (in_array($sAttCode, $aChangedAttCodes))
					{
						$aAttCodes[] = $sAttCode;
					}
				}
				if (empty($aAttCodes))
				{
					continue;
				}
				try
				{
					$sOQL = "SELECT $sLinkedClass WHERE ".implode(" = $sId UNION SELECT $sLinkedClass WHERE ", array_keys($aAttCodes)).' = '.$sId;
					$oSearch = DBObjectSearch::FromOQL($sOQL);
					$oSearch->AllowAllData();
					$sAliasClass = $oSearch->GetClassAlias();
					$oSet = new DBObjectSet($oSearch);
					$oSet->OptimizeColumnLoad(array($sAliasClass => array()));
					$oSet->Rewind();
					while ($oLinkedObject = $oSet->Fetch())
					{
						$sKey = $oLinkedObject->GetKey();
						self::AddAction($sLinkedClass, $sKey, OPERATION_REINDEX);
						self::PlanForReindexingExternalKeys($sLinkedClass, $sKey);
					}
				}
				catch (Exception $e)
				{
					IssueLog::Error($e->getMessage());
				}
			}
		}
	}

	/**
	 * Reindex All entries.
	 *
	 *
	 * @param bool $bRebuildInBackground if false -> interactive rebuild all
	 *
	 * @param string $sOperation
	 *
	 * @throws \CoreException
	 */
	public static function PlanForAllIndexRebuild($bRebuildInBackground = true, $sOperation = OPERATION_REBUILD)
	{
		$aClasses = self::GetSearchableClasses();
		foreach($aClasses as $sClass)
		{
			$sTableName = MetaModel::DBGetTable($sClass);
			$sKey = MetaModel::DBGetKey($sClass);
			$sReq = "SELECT {$sKey} AS id FROM `{$sTableName}`";
			try
			{
				$aResults = CMDBSource::QueryToArray($sReq);
				foreach ($aResults as $aResult)
				{
					self::AddAction($sClass, $aResult['id'], $sOperation);
				}
				self::InsertAllActions();
			}
			catch (Exception $e)
			{
				IssueLog::Error($e->getMessage());
			}
		}
		if (!$bRebuildInBackground)
		{
			set_time_limit(0);
			$bCompleted = false;
			while (!$bCompleted && !SetupUtils::IsInMaintenanceMode())
			{
				$bCompleted = FullTextIndexer::ReindexPendingEntries(time() + self::INDEXATION_TIME_SLOT);
			}
		}
	}

	protected static function AddAction($sClass, $sKey, $sOperation)
	{
		if (isset(self::$aDirtyObjects[$sClass][$sKey]))
		{
			return;
		}
		self::$aActions[] = array($sClass, $sKey, $sOperation, date('Y-m-d h:i:s'));
		self::$aDirtyObjects[$sClass][$sKey] = true;
	}

	protected static function InsertAllActions()
	{
		try
		{
			$sTableName = self::GetActionTableName();

			while (count(self::$aActions) > 0)
			{
				$sQuery = "INSERT INTO {$sTableName} (obj_class, obj_key, operation, creation_date) VALUES ";
				$aActionSQL = array();
				$iCount = 0;
				while ($iCount < 100)
				{
					if ($aAction = array_pop(self::$aActions))
					{
						$aActionSQL[] = "('{$aAction[0]}',{$aAction[1]},'{$aAction[2]}','{$aAction[3]}')";
						$iCount++;
					}
					else
					{
						break;
					}
				}
				$sQuery .= implode(',', $aActionSQL);
				CMDBSource::Query($sQuery);
			}
		}
		catch (Exception $e)
		{
			IssueLog::Error($e->getMessage());
		}
	}


	/**
	 * Reindex one object
	 *
	 * @param $sClass
	 * @param $sId
	 *
	 */
	public static function ReIndexObject($sClass, $sId)
	{
		try
		{
			$oObject = self::GetOneObject($sClass, $sId);
			if ($oObject)
			{
				self::ReIndexOneObject($oObject, $sClass, $sId);
				unset($oObject);
			}
			else
			{
				self::DeleteIndex($sClass, $sId);
			}
		}
		catch (Exception $e)
		{
			// ignored
		}
	}

	private static function GetOneObject($sClass, $sId)
	{
		$sQuery = "SELECT {$sClass} WHERE id = :id";
		$oFilter = DBSearch::FromOQL($sQuery);
		$oSet = new DBObjectSet($oFilter, array(), array('id' => $sId));
		$aColumnsToLoad = array();
		foreach (MetaModel::GetAttributesList($sClass) as $sAttCode)
		{
			$oAttDef = MetaModel::GetAttributeDef($sClass, $sAttCode);

			if (!($oAttDef instanceof AttributeBlob))
			{
				$aColumnsToLoad[] = $sAttCode;
			}
		}
		$oSet->OptimizeColumnLoad(array($sClass => $aColumnsToLoad));

		return $oSet->Fetch();
	}

	/**
	 * @param DBObject $oObject
	 * @param string $sClass
	 * @param string $sId
	 *
	 * @throws \CoreException
	 * @throws \MySQLException
	 * @throws \MySQLHasGoneAwayException
	 */
	protected static function ReIndexOneObject($oObject, $sClass, $sId)
	{
		$sTableName = self::GetIndexTableName();

		if ($oObject->IsArchived())
		{
			// Remove archived entries
			self::DeleteIndex($sClass, $sId);
			return;
		}

		$sFriendlyName = addslashes($oObject->get('friendlyname'));
		$sFriendlyName = substr($sFriendlyName, 0, 255);
		$s_FriendlyName = self::SanitizeValue($oObject->get('friendlyname'));
		$s_FriendlyName = substr($s_FriendlyName, 0, 255);
		$iObsolescenceFlag = $oObject->IsObsolete() ? 1 : 0;
		$iArchivedFlag = $oObject->IsArchived() ? 1 : 0;
		$sId = $oObject->GetKey();
		$sDetail = self::GetObjectDetails($oObject, $sClass, $sFriendlyName);

		$sOrgAttCode = UserRightsProfile::GetOwnerOrganizationAttCode($sClass);
		if (is_null($sOrgAttCode))
		{
			$iOrgId = 0;
		}
		else
		{
			$iOrgId = $oObject->Get($sOrgAttCode);
		}
		$sSelectQuery = "SELECT id FROM {$sTableName} WHERE obj_class='{$sClass}' AND obj_key={$sId}";
		$aResult = CMDBSource::QueryToArray($sSelectQuery);
		if (empty($aResult))
		{
			if (empty(self::$aClassWeight))
			{
				$aWeights = MetaModel::GetModuleSetting(FullTextUtils::GetModuleName(), 'object_weight_factor', array());
				foreach ($aWeights as $sWeightedClass => $fWeight)
				{
					self::SetAClassWeight($sWeightedClass, $fWeight);
				}
			}
			if (isset(self::$aClassWeight[$sClass]))
			{
				$fWeight = self::$aClassWeight[$sClass];
			}
			else
			{
				$fWeight = 1;
			}
			$sUpdateReq = "INSERT INTO {$sTableName} (obj_class, obj_key, org_id, obj_weight, friendlyname, _friendlyname, _detail, obsolescence_flag, archive_flag) VALUE ('{$sClass}', {$sId}, {$iOrgId}, $fWeight, '{$sFriendlyName}', '{$s_FriendlyName}', '{$sDetail}', {$iObsolescenceFlag}, $iArchivedFlag)";
		}
		else
		{
			$sUpdateReq = "UPDATE {$sTableName} SET org_id={$iOrgId}, friendlyname='{$sFriendlyName}', _friendlyname='{$s_FriendlyName}', _detail='{$sDetail}', obsolescence_flag={$iObsolescenceFlag}, archive_flag={$iArchivedFlag} WHERE obj_class='{$sClass}' AND obj_key={$sId}";
		}
		CMDBSource::Query($sUpdateReq);
	}

	/**
	 * Reindex all changed objects
	 *
	 * @param int $iMaxTime
	 *
	 * @return bool true if timeout
	 */
	public static function ReindexPendingEntries($iMaxTime = 0)
	{
		$oKPI = new ExecutionKPI();
		$bHasReIndexed = false;
		$aObjectsToUpdateByClass = self::ListObjectsToRefresh(OPERATION_REINDEX);
		while (!empty($aObjectsToUpdateByClass))
		{
			self::ReindexFromList($aObjectsToUpdateByClass, $iMaxTime);
			$bHasReIndexed = true;
			if (($iMaxTime > 0) && (time() > $iMaxTime))
			{
				break; // timeout
			}
			$aObjectsToUpdateByClass = self::ListObjectsToRefresh(OPERATION_REINDEX);
		}

		if ($iMaxTime == 0 || time() <= $iMaxTime)
		{
			$aObjectsToUpdateByClass = self::ListObjectsToRefresh(OPERATION_BUILD);
			while (!empty($aObjectsToUpdateByClass))
			{
				self::ReindexFromList($aObjectsToUpdateByClass, $iMaxTime);
				$bHasReIndexed = true;
				if (($iMaxTime > 0) && (time() > $iMaxTime))
				{
					break; // timeout
				}
				$aObjectsToUpdateByClass = self::ListObjectsToRefresh(OPERATION_BUILD);
			}
		}

		if ($iMaxTime == 0 || time() <= $iMaxTime)
		{
			$aObjectsToUpdateByClass = self::ListObjectsToRefresh(OPERATION_REBUILD);
			while (!empty($aObjectsToUpdateByClass))
			{
				self::ReindexFromList($aObjectsToUpdateByClass, $iMaxTime);
				$bHasReIndexed = true;
				if (($iMaxTime > 0) && (time() > $iMaxTime))
				{
					break; // timeout
				}
				$aObjectsToUpdateByClass = self::ListObjectsToRefresh(OPERATION_REBUILD);
			}
		}

		$oKPI->ComputeAndReport('Fulltext search indexation of pending changes');

		return (!$bHasReIndexed || $iMaxTime == 0 || time() <= $iMaxTime);
	}

	/**
	 * Get all the objects that generate a refresh in the fulltext table
	 *
	 * @param string $sOperation
	 * @param int $iLimit
	 *
	 * @return array in the form array[class][ID] = id
	 */
	public static function ListObjectsToRefresh($sOperation = OPERATION_REINDEX, $iLimit = POPULATE_LIMIT)
	{
		$sTableName = self::GetActionTableName();
		$aObjectList = array();
		$sReq = "SELECT id, obj_class, obj_key, operation FROM {$sTableName} WHERE operation='{$sOperation}' LIMIT {$iLimit}";
		try
		{
			$aResults = CMDBSource::QueryToArray($sReq);
			if (!empty($aResults))
			{
				foreach($aResults as $aResult)
				{
					$aObjectList[$aResult['obj_class']][$aResult['id']] = $aResult['obj_key'];
				}
			}
		}
		catch (MySQLException $e)
		{
			IssueLog::Error($e->getMessage());
		}

		return $aObjectList;
	}

	public static function GetNextClassToIndex()
	{
		$sTableName = self::GetActionTableName();
		$sClass = '';
		$sReq = "SELECT obj_class FROM {$sTableName} WHERE 1 LIMIT 1";
		try
		{
			$aResults = CMDBSource::QueryToArray($sReq);
			if (!empty($aResults))
			{
				foreach($aResults as $aResult)
				{
					$sClass = $aResult['obj_class'];
				}
			}
		}
		catch (MySQLException $e)
		{
			IssueLog::Error($e->getMessage());
		}

		return $sClass;
	}

    /**
     * Get the list of AttributeDefinition usable for index
     * @param string $sClass
     *
     * @return array of AttributeDefinition
     */
    public static function GetObjectAttDefsForIndex($sClass)
	{
		$aAttDefsForIndex = array();
		try
		{
			$aAttDefs = MetaModel::ListAttributeDefs($sClass);
			foreach($aAttDefs as $oAttDef)
			{
				if ($oAttDef->IsScalar())
				{
					switch (true)
					{
						case $oAttDef instanceof AttributeExternalField:
						case $oAttDef instanceof AttributeEncryptedString:
						case $oAttDef instanceof AttributeBlob:
						case $oAttDef instanceof AttributeImage:
						case $oAttDef instanceof AttributeOneWayPassword:
						case $oAttDef instanceof AttributePassword:
							break;

						default:
							$aAttDefsForIndex[] = $oAttDef;
							break;
					}
				}
			}
		}
		catch (CoreException $e)
		{
			IssueLog::Error($e->getMessage());
		}

		return $aAttDefsForIndex;
	}

	/**
	 * @param DBObject $oObject
	 * @param string $sClass
	 * @param $sFriendlyName
	 *
	 * @return string
	 */
	protected static function GetObjectDetails($oObject, $sClass, $sFriendlyName)
	{
		$sDetail = $sClass.' || '.$sFriendlyName;
		$aDetails = array();
		$aAttDefs = self::GetObjectAttDefsForIndex($sClass);
		foreach($aAttDefs as $oAttDef)
		{
			if (!($oAttDef instanceof AttributeBlob))
			{
				$sValue = self::GetAttributeDetail($oObject, $oAttDef);
				if (!empty($sValue) && strlen($sValue) > 3)
				{
					if (!in_array($sValue, $aDetails))
					{
						$aDetails[] = $sValue;
						$sValue = self::SanitizeValue($sValue);
						$sDetail .= ' || '.$sValue;
					}
				}
			}
			unset($oAttDef);
		}

		return trim($sDetail);
	}

	/**
	 * @param DBObject $oObject
	 * @param AttributeDefinition $oAttDef
	 *
	 * @return string
	 */
	protected static function GetAttributeDetail($oObject, $oAttDef)
	{
		$sAttCode = $oAttDef->GetCode();
		try
		{
			if ($oAttDef->IsExternalKey())
			{
				$oValue = $oObject->Get($sAttCode.'_friendlyname');
			}
			else
			{
				$oValue = $oObject->Get($sAttCode);
			}
			if (!is_string($oValue))
			{
				if (method_exists($oValue, 'GetAsPlainText'))
				{
					$oValue = $oValue->GetAsPlainText();
				}
				else
				{
					$oValue = $oAttDef->GetAsPlainText($oValue);
				}
			}
			if (is_scalar($oValue))
			{
				$sValue = trim("$oValue");
				unset ($oValue);

				return $sValue;
			}
			unset ($oValue);
		}
		catch (Exception $e)
		{
			IssueLog::Error($e->getMessage());
		}

		return '';
	}

	/**
	 * Set an additional weight for a specific object class
	 *
	 * @param string $sClass Class name
	 * @param float $fWeight Additional weight for the class
	 */
	public static function SetAClassWeight($sClass, $fWeight)
	{
		self::$aClassWeight[$sClass] = $fWeight;
	}

	/**
	 * Create the fulltext database table if not exists
	 *
	 * @throws \CoreException
	 * @throws \MySQLException
	 * @throws \MySQLHasGoneAwayException
	 */
	public static function CreateFullTextTable()
	{
		// Create Index table
		$sEngine = 'InnoDB';
		$sIndexTableName = self::GetIndexTableName();
		$sCreateTable = <<<SQL
CREATE TABLE IF NOT EXISTS {$sIndexTableName} (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    obj_class VARCHAR(255) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    obj_key INTEGER(11) NOT NULL,
    org_id INTEGER(11) NOT NULL,
    obsolescence_flag INTEGER(1) NOT NULL,
    archive_flag INTEGER(1) NOT NULL,
    friendlyname VARCHAR(255) NOT NULL,
    _friendlyname VARCHAR(255) NOT NULL,
    obj_weight FLOAT,
    _detail LONGTEXT NOT NULL,
    PRIMARY KEY(id),
    FULLTEXT INDEX search_fulltext_fullindex(_detail),
    UNIQUE INDEX search_fulltext_index(obj_class, obj_key),
    UNIQUE INDEX id_index(id)
)
ENGINE={$sEngine} CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
SQL;
		CMDBSource::Query($sCreateTable);

		// Create action table
		$sActionTableName = self::GetActionTableName();
		$sCreateTable = <<<SQL
CREATE TABLE IF NOT EXISTS {$sActionTableName} (
    id INTEGER UNSIGNED NOT NULL AUTO_INCREMENT,
    obj_class VARCHAR(255) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    obj_key INTEGER(11) NOT NULL,
    operation ENUM('reindex','rebuild','build'),
    creation_date DATETIME,
    PRIMARY KEY(id),
    UNIQUE INDEX id_index(id)
)
ENGINE={$sEngine} CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
SQL;
		CMDBSource::Query($sCreateTable);

		// Migration
		$sAlterTable = "ALTER TABLE {$sActionTableName} CHANGE operation operation ENUM('reindex','rebuild','build') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;";
		CMDBSource::Query($sAlterTable);
	}

	/**
	 * Populate the fulltext database table with the content of the iTop database
	 *
	 * @throws \Exception
	 */
	public static function PopulateDB()
	{
		// Needs exclusive mode to drop/create database table
		SetupUtils::EnterMaintenanceMode(MetaModel::GetConfig());
		self::EraseDB();
		self::CreateFullTextTable();
		SetupUtils::ExitMaintenanceMode();

		self::$aBulkInserts = array();
		$oKPI = new ExecutionKPI();
		MemoryKpiLog::SetTitle("Class Index");
		try
		{
			CMDBSource::Query('SET unique_checks=0');
			CMDBSource::Query('START TRANSACTION');
			$iInsertIndex = 0;
			$aClasses = self::GetSearchableClasses();
			foreach($aClasses as $sClass)
			{
				self::PopulateOneClass($sClass, $iInsertIndex);
			}
            CMDBSource::Query('COMMIT');
            CMDBSource::Query('SET unique_checks=1');
		}
		catch (Exception $e)
		{
			IssueLog::Error($e->getMessage());
			try
			{
				CMDBSource::Query('ROLLBACK');
			}
			catch (Exception $e)
			{
				IssueLog::Error($e->getMessage());
			}
		}

		$aMemoryUsage[] = MemoryKpi::GetResultFooter();

		$oKPI->ComputeAndReport('Fulltext search initial indexation');

		return $aMemoryUsage;
	}

    /**
     * @param $sClass
     * @param $iInsertIndex
     *
     * @throws \CoreException
     * @throws \CoreUnexpectedValue
     * @throws \MySQLException
     * @throws \OQLException
     */
	protected static function PopulateOneClass($sClass, &$iInsertIndex)
	{
		set_time_limit(3600);
		MemoryKpiLog::MeasureStartPoint($sClass);
		$iMemoryUsageStart = memory_get_usage(true);
		$iMemoryLimit = MemoryKpi::GetMemoryLimit() * 0.8;
		$oSearch = DBObjectSearch::FromOQL('SELECT '.$sClass);
		$oSearch->AllowAllData();
		$iPopulateLimit = POPULATE_LIMIT;
		$iStart = 0;
		do
		{
			$oSet = new DBObjectSet($oSearch, array(), array(), null, $iPopulateLimit, $iStart, false);
			$aAttDefs = self::GetObjectAttDefsForIndex($sClass);
			$aAttCodes = array();
			foreach($aAttDefs as $oAttDef)
			{
				$aAttCodes[] = $oAttDef->GetCode();
			}
			$oSet->OptimizeColumnLoad(array($sClass => $aAttCodes));
			$iRetry = 3;
			$iLocalCount = 0;
			while ($iRetry > 0)
			{
				while ($oObject = $oSet->Fetch())
				{
					$iLocalCount++;
					self::BulkInsertObject($oObject, $sClass, $iInsertIndex + $iLocalCount);
					unset($oObject);
					$iMemoryUsage = memory_get_usage(true);
					if ((self::$iInsertBufferLength > 1024 * 1024) || ($iMemoryUsage + ($iMemoryUsage - $iMemoryUsageStart) > $iMemoryLimit))
					{
						// The memory is nearly exhausted, reduce the step and insert the rows now
						$iPopulateLimit = (int)($iPopulateLimit / 2) + 1;
						unset($oSet);
						if (function_exists('gc_collect_cycles'))
						{
							gc_collect_cycles();
						}
						MemoryKpiLog::MeasureIntermediatePoint($sClass, "$sClass $iStart ($iLocalCount)");
						break;
					}
				}
				try
				{
					self::InsertAllObjects();
                    CMDBSource::Query('COMMIT');
                    CMDBSource::Query('START TRANSACTION');
					$iInsertIndex += $iLocalCount;
					$iStart += $iLocalCount;
					$iRetry = 0;
				}
				catch (Exception $e)
				{
					$iRetry--;
					$iLocalCount = 0;
					usleep(rand(100000));
					IssueLog::Error($e->getMessage());
				}
			}
			if (isset($oSet))
			{
				unset($oSet);
			}
		} while ($iLocalCount != 0);

		unset($oSearch);
		if (function_exists('gc_collect_cycles'))
		{
			gc_collect_cycles();
		}
		MemoryKpiLog::MeasureEndPoint($sClass, "$sClass ($iStart)");
	}

	/**
	 * Insert an object into the fulltext database index
	 *
	 * @param DBObject $oObject Object to insert
	 * @param string $sClass class name of the object
	 * @param int $iInsertIndex
	 */
	protected static function BulkInsertObject($oObject, $sClass, $iInsertIndex)
	{
		try
		{
			if ($oObject->IsArchived())
			{
				return;
			}
			$aWeights = MetaModel::GetModuleSetting(FullTextUtils::GetModuleName(), 'object_weight_factor', array());
			foreach($aWeights as $sWeightedClass => $fWeight)
			{
				self::SetAClassWeight($sWeightedClass, $fWeight);
			}
			$sFriendlyName = addslashes($oObject->get('friendlyname'));
			$s_FriendlyName = self::SanitizeValue($oObject->get('friendlyname'));
			$iObsolescenceFlag = $oObject->IsObsolete() ? 1 : 0;
			$iArchivedFlag = $oObject->IsArchived() ? 1 : 0;
			$sId = $oObject->GetKey();
			$sDetail = self::GetObjectDetails($oObject, $sClass, $sFriendlyName);

			// Get the organization of the object
			$sOrgAttCode = UserRightsProfile::GetOwnerOrganizationAttCode($sClass);
			if (is_null($sOrgAttCode))
			{
				$iOrgId = 0;
			}
			else
			{
				$iOrgId = $oObject->Get($sOrgAttCode);
			}
			if (isset(self::$aClassWeight[$sClass]))
			{
				$fWeight = self::$aClassWeight[$sClass];
			}
			else
			{
				$fWeight = 1;
			}
			$sInsertParams = "($iInsertIndex, '{$sClass}', {$sId}, {$iOrgId}, $fWeight, '{$sFriendlyName}', '{$s_FriendlyName}', '{$sDetail}', {$iObsolescenceFlag}, $iArchivedFlag)";
			self::$aBulkInserts[] = $sInsertParams;
			self::$iInsertBufferLength += strlen($sInsertParams);
			unset($sDetail);
		}
		catch (Exception $e)
		{
			IssueLog::Error($e->getMessage());
		}
	}

	protected static function InsertAllObjects()
	{
		$sTableName = self::GetIndexTableName();
		try
		{
			if (count(self::$aBulkInserts) > 0)
			{
				$sQuery = "INSERT INTO {$sTableName} (id, obj_class, obj_key, org_id, obj_weight, friendlyname, _friendlyname, _detail, obsolescence_flag, archive_flag) VALUES ";
				$sQuery .= implode(',', self::$aBulkInserts);
				CMDBSource::Query($sQuery);
				unset($sQuery);
			}
		}
		catch (Exception $e)
		{
			// Bulk failed, try again line by line
			foreach(self::$aBulkInserts as $sData)
			{
				try
				{
					$sQuery = "INSERT INTO {$sTableName} (id, obj_class, obj_key, org_id, obj_weight, friendlyname, _friendlyname, _detail, obsolescence_flag, archive_flag) VALUES {$sData}";
					CMDBSource::Query($sQuery);
					unset($sQuery);
				}
				catch (Exception $e)
				{
					IssueLog::Error($e->getMessage());
				}
			}
		}
		self::$aBulkInserts = array();
		self::$iInsertBufferLength = 0;
	}

	/**
	 * Get a list of all the searchable classes with all the classes linking to them.
	 *
	 * @return array The model big picture of the dependencies in the form
	 *     array[target_class][linking_class][link_attrcode] = true
	 */
	private static function GetFriendlynameLinks()
	{
		if (!empty(self::$aClassLinks))
		{
			return self::$aClassLinks;
		}
		$aDependencies = array();
		foreach(self::GetSearchableClasses() as $sClass)
		{
			try
			{
				$aAttDefs = MetaModel::ListAttributeDefs($sClass);
				$aAttCodes = MetaModel::GetFriendlyNameAttributeCodeList($sClass);
				foreach($aAttCodes as $sAttCode)
				{
					$oAttDef = $aAttDefs[$sAttCode];
					if ($oAttDef instanceof AttributeExternalField)
					{
						$oKeyAttDef = $oAttDef->GetKeyAttDef();
						$sLinkedClass = $oKeyAttDef->GetTargetClass();
						$sKeyAttCode = $oKeyAttDef->GetKeyAttCode();
						// Get all the children class
						$aLinkedClasses = MetaModel::EnumChildClasses($sLinkedClass, ENUM_CHILD_CLASSES_ALL);
						foreach($aLinkedClasses as $sTargetClass)
						{
							$aDependencies[$sTargetClass][$sClass][$sKeyAttCode] = true;
						}
					}
				}
			}
			catch (Exception $e)
			{
				IssueLog::Error($e->getMessage());
			}

		}
		self::$aClassLinks = $aDependencies;

		return self::$aClassLinks;
	}

	/**
	 * Build a list of all the searchable classes with all the classes linking to them (n-1).
	 * Build a list of all the indirect links (n-n).
	 */
	protected static function BuildExternalKeyLinks()
	{
		if (!empty(self::$aClassExternalKeyLinks))
		{
			return;
		}
		$aDependencies = array();
		$aIndirectDependencies = array();
		foreach(self::GetSearchableClasses() as $sClass)
		{
			try
			{
				$aAttDefs = MetaModel::ListAttributeDefs($sClass);
				foreach($aAttDefs as $oAttDef)
				{
					if ($oAttDef instanceof AttributeExternalKey)
					{
						$sLinkedClass = $oAttDef->GetTargetClass();
						$sKeyAttCode = $oAttDef->GetKeyAttCode();
						// Get all the children class
						$aLinkedClasses = MetaModel::EnumChildClasses($sLinkedClass, ENUM_CHILD_CLASSES_ALL);
						foreach($aLinkedClasses as $sTargetClass)
						{
							$aDependencies[$sTargetClass][$sClass][$sKeyAttCode] = true;
						}
					}
					else if ($oAttDef instanceof AttributeLinkedSetIndirect)
					{
						/** @var AttributeLinkedSetIndirect $oAttDef */
						$sLnkClass = $oAttDef->GetLinkedClass();
						$sExtKeyToMeAttCode = $oAttDef->GetExtKeyToMe();
						$sExtKeyToRemote = $oAttDef->GetExtKeyToRemote();
						/** @var AttributeExternalKey $oExtKeyToRemoteAttDef */
						$oExtKeyToRemoteAttDef = MetaModel::GetAttributeDef($sLnkClass, $sExtKeyToRemote);
						$sIndirectLinkedClass = $oExtKeyToRemoteAttDef->GetTargetClass();
						$aLinkedClasses = MetaModel::EnumChildClasses($sIndirectLinkedClass, ENUM_CHILD_CLASSES_ALL);
						foreach($aLinkedClasses as $sTargetClass)
						{
							$aIndirectDependencies[$sTargetClass][$sLnkClass][$sExtKeyToRemote][$sClass] = $sExtKeyToMeAttCode;
						}
					}
				}
			}
			catch (Exception $e)
			{
				IssueLog::Error($e->getMessage());
			}

		}
		self::$aClassExternalKeyLinks = $aDependencies;
		self::$aClassIndirectLinks = $aIndirectDependencies;
	}

	/**
	 * Drop the fulltext database table
	 */
	public static function EraseDB()
	{
		$sTableName = self::GetIndexTableName();
		$sQuery = "DROP TABLE IF EXISTS {$sTableName}";
		try
		{
			CMDBSource::Query($sQuery);
		}
		catch (Exception $e)
		{
			IssueLog::Error($e->getMessage());
		}
		$sTableName = self::GetActionTableName();
		$sQuery = "DROP TABLE IF EXISTS {$sTableName}";
		try
		{
			CMDBSource::Query($sQuery);
		}
		catch (Exception $e)
		{
			IssueLog::Error($e->getMessage());
		}
	}

	/**
	 * @param string $sOperation reindex, rebuild, build
	 *
	 * @return int
	 */
	public static function CountPendingActions($sOperation = 'reindex')
	{
		$sTableName = self::GetActionTableName();
		$sCountQuery = "SELECT COUNT(*) FROM {$sTableName} WHERE operation = '{$sOperation}'";
		try
		{
			return CMDBSource::QueryToScalar($sCountQuery);
		}
		catch (MySQLException $e)
		{
			IssueLog::Error($e->getMessage());
			return 0;
		}
	}

	/**
	 * @return bool
	 */
	public static function HasPendingActions()
	{
		$sTableName = self::GetActionTableName();
		$sCountQuery = "SELECT * FROM {$sTableName} WHERE `operation` != 'rebuild' LIMIT 1";
		try
		{
			$aResults = CMDBSource::QueryToArray($sCountQuery);

			return !empty($aResults);
		}
		catch (MySQLException $e)
		{
			IssueLog::Error($e->getMessage());
		}

		return false;
	}

	/**
	 * Get the list of classes where fulltext search is performed
	 *
	 * @return array List of class names
	 */
	protected static function GetSearchableClasses()
	{
		static $aClasses = array();
		if (!empty($aClasses))
		{
			return $aClasses;
		}
		try
		{
			$aExcludedClasses = MetaModel::GetModuleSetting(FullTextUtils::GetModuleName(), 'excluded_classes', array());
			$aLinkClasses = MetaModel::GetLinkClasses();
			foreach(MetaModel::GetClasses('searchable') as $sClass)
			{
				if (!MetaModel::IsAbstract($sClass) && !isset($aLinkClasses[$sClass]) && !in_array($sClass, $aExcludedClasses))
				{
					$aClasses[] = $sClass;
				}
			}
		}
		catch (CoreException $e)
		{
			IssueLog::Error($e->getMessage());
		}

		return $aClasses;
	}


	/** Get the Search Actions table name
	 *
	 * @return string
	 */
	public static function GetActionTableName()
	{
		return self::GetTablePrefix().'fulltext_search_action';
	}

	/** Get the Search Index MySQL table name
	 *
	 * @return string
	 */
	public static function GetIndexTableName()
	{
		return self::GetTablePrefix().'fulltext_search_index';
	}

	protected static function GetTablePrefix()
	{
		if (MetaModel::GetConfig()->IsProperty('db_subname'))
		{
			$sDBSubname = MetaModel::GetConfig()->Get('db_subname');

			return is_null($sDBSubname) ? '' : $sDBSubname;
		}

		return '';
	}

	/**
	 * @param $oValue
	 *
	 * @return mixed|string
	 */
	public static function SanitizeValue($oValue)
	{
		$sValue = trim("$oValue");
		if (strlen($sValue) > 2)
		{
			// HTML fields are encoded
			$sValue = html_entity_decode($sValue);

			// Email address split to consider also the domain
			$sValue = preg_replace("/(\S+(@(\S+)))/", '$1 $2 $3', $sValue);

			// remove trailing .
			$sValue = preg_replace("/\.$|\.(?=\s)/", '', $sValue);

			// remove '-' or '+' inside words (prevent the search of this word)
			$sValue = preg_replace("/(?<=\S)[-+](?=\S)/", '_', $sValue);

			// remove '-' alone -> returns no result
            $sValue = preg_replace("/(?<=\s)-(?=\s)/", '', $sValue);

			// Quotes, coma, # and . ending phrase are separators
			$sValue = str_replace(array("'", ',', '#', '. ', '>', '<'), ' ', $sValue);

			// . @ and / are not separators
			$sValue = str_replace(array('.', "@", '/', '(', ')'), '_', $sValue);

			return addslashes($sValue);
		}

		return '';
	}


    /**
     * @param $sValue
     *
     * @return mixed|string
     */
    protected static function GetNeedleForWordOrder($sValue)
    {
        if (empty($sValue) || (($sValue[0] == '"') && ($sValue[strlen($sValue) - 1] == '"')))
        {
            return $sValue;
        }

        $aMainWordList = array();
        $aSupprWordList = array();
        self::ExplodeWords($sValue, $aMainWordList, $aSupprWordList);

        if ((count($aMainWordList) == 1) && (count($aSupprWordList) == 0))
        {
            $sValue = $aMainWordList[0].'*';
        }
        else
        {
            $sValue = '"'.implode(' ', $aMainWordList).'" '.implode(' ', $aSupprWordList);
        }

        return trim($sValue);
    }

    /**
     * @param $sValue
     *
     * @return mixed|string
     */
    protected static function GetNeedleForHighlight($sValue)
    {
        $aMainWordList = array();
        $aSupprWordList = array();
        self::ExplodeWords($sValue, $aMainWordList, $aSupprWordList);

        $sValue = implode(' ', $aMainWordList);

        return trim($sValue);
    }

    /**
     * @param $sValue
     * @param $aSupprWordList
     * @param $aMainWordList
     */
    protected static function ExplodeWords($sValue, &$aMainWordList, &$aSupprWordList)
    {
        // Suppress MySQL characters
        $sValue = str_replace(array('"', '*', '+', '<', '>', '(', ')', '~', "'"), '', $sValue);

        $aWords = explode(' ', $sValue);
        foreach($aWords as $sWord)
        {
        	if (!empty($sWord))
	        {
		        if ($sWord[0] == '-')
		        {
			        $aSupprWordList[] = $sWord;
		        }
		        else
		        {
			        $aMainWordList[] = $sWord;
		        }
	        }
        }
    }

	protected static function SanitizeMySQLChars($sValue)
    {
        $sValue = str_replace(array('"', '<', '>', '(', ')', '~', "'", "|"), '', $sValue);

        // Remove - prefix
        $sValue = preg_replace('@^-(?=\w+)|(?<=\s)-(?=\w+)@u', '', $sValue);
        $sValue = preg_replace('@^\+(?=\w+)|(?<=\s)\+(?=\w+)@u', '', $sValue);
        $sValue = preg_replace('@\*(?=\s)|(?<=\w)\*$@u', '', $sValue);

        return $sValue;
    }

	public static function GetMicroTime()
	{
		list($usec, $sec) = explode(" ", microtime());

		return ((float)$usec + (float)$sec);
	}

	/**
	 * @param array $aObjectsToUpdateByClass
	 * @param $iMaxTime
	 */
	protected static function ReindexFromList(array $aObjectsToUpdateByClass, $iMaxTime)
	{
		try
		{
			$aActionsToRemove = array();
			foreach ($aObjectsToUpdateByClass as $sClass => $aIdsToUpdate)
			{
				if (($iMaxTime > 0) && (time() > $iMaxTime))
				{
					break; // timeout
				}

				try
				{
					CMDBSource::Query('START TRANSACTION');
					foreach ($aIdsToUpdate as $iActionId => $sId)
					{
						FullTextSearch::ReIndexObject($sClass, $sId);
						$aActionsToRemove[] = $iActionId;
						if (($iMaxTime > 0) && (time() > $iMaxTime))
						{
							break; // timeout
						}
					}
					CMDBSource::Query('COMMIT');
				} catch (Exception $e)
				{
					IssueLog::Error($e->getMessage());
					CMDBSource::Query('ROLLBACK');
				}
			}
			// Clean action table
			if (!empty($aActionsToRemove))
			{
				$sTableName = self::GetActionTableName();
				$sDeleteReq = "DELETE FROM {$sTableName} WHERE id IN (".implode(',', $aActionsToRemove).")";
				CMDBSource::Query($sDeleteReq);
			}
		}
		catch (Exception $e)
		{
			IssueLog::Error($e->getMessage());
		}
	}
}
