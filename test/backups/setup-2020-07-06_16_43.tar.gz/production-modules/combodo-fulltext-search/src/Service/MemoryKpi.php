<?php
/**
 * @copyright   Copyright (C) 2010-2020 Combodo SARL
 * @license     http://opensource.org/licenses/AGPL-3.0
 */


namespace Combodo\iTop\FullTextSearch\Service;


use MyHelpers;

class MemoryKpi
{
	private $fStartTime;
	private $fElapsedTime;
	private $iMemoryPeak;
	private $iDeltaMemory;
	private $iMemoryEnd;
	private $iMemoryStart;

	function __construct()
	{
		$this->fStartTime = MyHelpers::getmicrotime();
		$this->iMemoryStart = memory_get_usage(true);
	}

	public function MeasurePoint()
	{
		$this->fElapsedTime = round(MyHelpers::getmicrotime() - $this->fStartTime, 3);

		$iMemoryEnd = memory_get_usage(true);
		$this->iDeltaMemory = $iMemoryEnd - $this->iMemoryStart;
		$this->iMemoryEnd = $iMemoryEnd;
		$this->iMemoryPeak = memory_get_peak_usage(true);
	}

	public static function GetResultHeader($sTitle, $sFormat = 'HTML')
	{
		switch ($sFormat)
		{
			case 'HTML':
				$sOutput = "<table class='listContainer'><tbody><tr><td>";
				$sOutput .= "<table class='listResults'><thead>";
				$sOutput .= self::GetResultSeparator($sTitle, $sFormat);
				$sOutput .= "</thead><tbody>";
				break;

			default:
				$sOutput = self::GetResultSeparator($sTitle, $sFormat);;
		}
		return $sOutput;
	}

	public static function GetResultSeparator($sTitle, $sFormat = 'HTML')
	{
		switch ($sFormat)
		{
			case 'HTML':
				$sOutput = "<tr><th>$sTitle</th><th>Elapsed</th><th>Mem Start</th><th>Mem End</th><th>Diff</th><th>Peak</th></tr>";
				break;

			default:
				$sOutput = "\n{$sTitle}\tElapsed\tMem Start\tMem End\tDiff\tPeak\n";
		}
		return $sOutput;
	}

	public function GetResultLine($sMessage, $sFormat = 'HTML')
	{
		$fElapsedTime = round($this->fElapsedTime, 3);
		$iMemoryPeak = self::ToMega($this->iMemoryPeak);
		$iDeltaMemory = self::ToMega($this->iDeltaMemory);
		$iMemoryEnd = self::ToMega($this->iMemoryEnd);
		$iMemoryStart = self::ToMega($this->iMemoryStart);

		switch ($sFormat)
		{
			case 'HTML':
				$sOutput = "<tr><td>{$sMessage}</td><td>{$fElapsedTime}s</td><td>{$iMemoryStart}M</td><td>{$iMemoryEnd}M</td><td>{$iDeltaMemory}M</td><td>{$iMemoryPeak}M</td></tr>";
				break;

			default:
				$sOutput = "{$sMessage}\t{$fElapsedTime}s\t{$iMemoryStart}M\t{$iMemoryEnd}M\t{$iDeltaMemory}M\t{$iMemoryPeak}M\n";
		}
		return $sOutput;
	}

	public static function GetResultFooter($sFormat = 'HTML')
	{
		switch ($sFormat)
		{
			case 'HTML':
				$sOutput = "</tbody></table></td></tr></tbody></table>";
				break;

			default:
				$sOutput = "\n";
		}
		return $sOutput;
	}

	public static function ToMega($iSizeInBytes)
	{
		return round($iSizeInBytes / 1024.0 / 1024.0, 3);
	}

	public static function GetMemoryLimit()
	{
		$sLimit = ini_get('memory_limit');
		if ($sLimit == '-1')
		{
			return 128 * 1048576;
		}
		switch (substr ($sLimit, -1))
		{
			case 'M': case 'm': return (int)$sLimit * 1048576;
			case 'K': case 'k': return (int)$sLimit * 1024;
			case 'G': case 'g': return (int)$sLimit * 1073741824;
			default: return (int)$sLimit;
		}
	}
}
