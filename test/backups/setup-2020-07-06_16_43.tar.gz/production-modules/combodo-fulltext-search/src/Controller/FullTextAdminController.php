<?php
/**
 * @copyright   Copyright (C) 2010-2020 Combodo SARL
 * @license     http://opensource.org/licenses/AGPL-3.0
 */


namespace Combodo\iTop\FullTextSearch\Controller;


use BackgroundTask;
use Combodo\iTop\Application\TwigBase\Controller\Controller;
use Combodo\iTop\FullTextSearch\Service\FullTextSearch;
use Combodo\iTop\FullTextSearch\Service\FullTextUtils;
use DBObjectSet;
use DBSearch;
use Exception;
use FullTextBackgroundRebuildFullIndex;
use IssueLog;
use utils;

class FullTextAdminController extends Controller
{
	/**
	 * @throws \Exception
	 */
	public function OperationPopulate()
	{
		$aParams = array();
		$this->AddSaas('env-'.utils::GetCurrentEnvironment().'/'.FullTextUtils::GetModuleName().'/css/'.FullTextUtils::GetModuleName().'.scss');
		try
		{
			set_time_limit(0);
			$fStart = FullTextSearch::GetMicroTime();
			FullTextSearch::PlanForAllIndexRebuild(false);
			$fDuration = FullTextSearch::GetMicroTime() - $fStart;
			$iCount = FullTextSearch::TotalSearchEntries();
			$fRate = round($iCount / $fDuration);
			$fDuration = round($fDuration);
			$aParams['iCount'] = $iCount;
			$aParams['iDuration'] = $fDuration;
			$aParams['iRate'] = $fRate;

			$oBackgroundProcess = new FullTextBackgroundRebuildFullIndex();
			$aParams['sStatus'] = $oBackgroundProcess->GetDisplayStatus();
			$aParams['iEntries'] = FullTextSearch::TotalSearchEntries();
			$aParams['sLimit'] = ini_get('memory_limit');
			$aParams['iMemoryPeak'] = round(memory_get_peak_usage(true) / 1024 / 1024, 2);
			$aParams['sAdminLinkURL'] = utils::GetAbsoluteUrlModulePage(FullTextUtils::GetModuleName(), 'index-admin.php');
		}
		catch (Exception $e)
		{
			IssueLog::Error($e->getMessage());
			$aParams['sError'] = $e->getMessage();
		}

		$this->DisplayPage($aParams);
	}

	/**
	 * @throws \Exception
	 */
	public function OperationRefresh()
	{
		$aParams = array();
		$this->AddSaas('env-'.utils::GetCurrentEnvironment().'/'.FullTextUtils::GetModuleName().'/css/'.FullTextUtils::GetModuleName().'.scss');
		try
		{
			set_time_limit(0);
			$fStart = FullTextSearch::GetMicroTime();
			$iCount = FullTextSearch::CountPendingActions();
			FullTextSearch::ReindexPendingEntries();
			$fDuration = FullTextSearch::GetMicroTime() - $fStart;
			$fRate = round($iCount / $fDuration);
			$fDuration = round($fDuration);
			$aParams['iCount'] = $iCount;
			$aParams['iDuration'] = $fDuration;
			$aParams['iRate'] = $fRate;

			$oBackgroundProcess = new FullTextBackgroundRebuildFullIndex();
			$aParams['sStatus'] = $oBackgroundProcess->GetDisplayStatus();
			$aParams['iEntries'] = FullTextSearch::TotalSearchEntries();
			$aParams['sLimit'] = ini_get('memory_limit');
			$aParams['iMemoryPeak'] = round(memory_get_peak_usage(true) / 1024 / 1024, 2);
			$aParams['sAdminLinkURL'] = utils::GetAbsoluteUrlModulePage(FullTextUtils::GetModuleName(), 'index-admin.php');
		}
		catch (Exception $e)
		{
			IssueLog::Error($e->getMessage());
			$aParams['sError'] = $e->getMessage();
		}

		$this->DisplayPage($aParams);
	}

	/**
	 * @throws \Exception
	 */
	public function OperationRefreshAll()
	{
		$aParams = array();
		$this->AddSaas('env-'.utils::GetCurrentEnvironment().'/'.FullTextUtils::GetModuleName().'/css/'.FullTextUtils::GetModuleName().'.scss');
		try
		{
			set_time_limit(0);
			$fStart = FullTextSearch::GetMicroTime();
			FullTextSearch::PlanForAllIndexRebuild();
			$iCount = FullTextSearch::CountPendingActions();
			//FullTextSearch::ReindexPendingEntries();
			$fDuration = FullTextSearch::GetMicroTime() - $fStart;
			$fRate = round($iCount / $fDuration);
			$fDuration = round($fDuration);
			$aParams['iCount'] = $iCount;
			$aParams['iDuration'] = $fDuration;
			$aParams['iRate'] = $fRate;

			$oBackgroundProcess = new FullTextBackgroundRebuildFullIndex();
			$aParams['sStatus'] = $oBackgroundProcess->GetDisplayStatus();
			$aParams['iEntries'] = FullTextSearch::TotalSearchEntries();
			$aParams['sLimit'] = ini_get('memory_limit');
			$aParams['iMemoryPeak'] = round(memory_get_peak_usage(true) / 1024 / 1024, 2);
			$aParams['sAdminLinkURL'] = utils::GetAbsoluteUrlModulePage(FullTextUtils::GetModuleName(), 'index-admin.php');
		}
		catch (Exception $e)
		{
			IssueLog::Error($e->getMessage());
			$aParams['sError'] = $e->getMessage();
		}

		$this->DisplayPage($aParams);
	}

	/**
	 * @throws \Exception
	 */
	public function OperationAdmin()
	{
		$aParams = array();
		$this->AddSaas('env-'.utils::GetCurrentEnvironment().'/'.FullTextUtils::GetModuleName().'/css/'.FullTextUtils::GetModuleName().'.scss');
		try
		{
			$aParams['iCountPending'] = FullTextSearch::CountPendingActions(OPERATION_REINDEX);
			$aParams['iCountRebuild'] = FullTextSearch::CountPendingActions(OPERATION_REBUILD);
			$aParams['iCountBuild'] = FullTextSearch::CountPendingActions(OPERATION_BUILD);
			$aParams['sClassToIndex'] = FullTextSearch::GetNextClassToIndex();
			$aParams['iEntries'] = FullTextSearch::TotalSearchEntries();

			$aParams['sPopulateLink'] = utils::GetAbsoluteUrlModulePage(FullTextUtils::GetModuleName(), 'index-admin.php', array('operation' => 'Populate'));
			$aParams['sRefreshLink'] = utils::GetAbsoluteUrlModulePage(FullTextUtils::GetModuleName(), 'index-admin.php').'&operation=Refresh';
			$aParams['sRefreshAllLink'] = utils::GetAbsoluteUrlModulePage(FullTextUtils::GetModuleName(), 'index-admin.php').'&operation=RefreshAll';

			$aParams['sAjaxURL'] =  utils::GetAbsoluteUrlModulePage(FullTextUtils::GetModuleName(), 'index-ajax.php');

			$oSet = new DBObjectSet(DBSearch::FromOQL("SELECT BackgroundTask WHERE class_name = 'FullTextBackgroundRefresh'"));
			if ($oSet->Count() != 1)
			{
				$aParams['bBackgroundRefresh'] = false;
			}
			else
			{
				/** @var BackgroundTask $oBackgroundTask */
				$oBackgroundTask = $oSet->Fetch();
				$aParams['latest_run_date'] = $oBackgroundTask->Get('latest_run_date');
				$aParams['next_run_date'] = $oBackgroundTask->Get('next_run_date');
			}

			$oBackgroundProcess = new FullTextBackgroundRebuildFullIndex();
			$aParams['sStatus'] = $oBackgroundProcess->GetDisplayStatus();
			$aParams['sLimit'] = ini_get('memory_limit');
			$aParams['iMemoryPeak'] = round(memory_get_peak_usage(true) / 1024 / 1024, 2);
		}
		catch (Exception $e)
		{
			IssueLog::Error($e->getMessage());
			$aParams['sError'] = $e->getMessage();
		}

		$this->DisplayPage($aParams, 'Admin');
	}
}
