<?php
/**
 * @copyright   Copyright (C) 2010-2020 Combodo SARL
 * @license     http://opensource.org/licenses/AGPL-3.0
 */


namespace Combodo\iTop\FullTextSearch\Controller;


use AttributeExternalKey;
use CMDBSource;
use Combodo\iTop\Application\TwigBase\Controller\Controller;
use Combodo\iTop\FullTextSearch\Service\FullTextSearch;
use Combodo\iTop\FullTextSearch\Service\FullTextUtils;
use Dict;
use Exception;
use MetaModel;
use MyHelpers;
use UserRights;
use utils;

class FullTextController extends Controller
{
	/**
	 * @throws \CoreException
	 * @throws \DictExceptionMissingString
	 * @throws \Exception
	 */
	public function OperationDisplayRelated()
	{
		$aParams = array();

		$sRefClass = utils::ReadParam('class', '');
		$sKey = utils::ReadParam('key', 0);
		$sFriendlyName = utils::ReadParam('friendlyname', '');

		$aParams['sPageTitle'] = Dict::Format('FulltextSearch:RelatedToTitle', MetaModel::GetName($sRefClass), $sFriendlyName);

		$aRelatedObjects = FullTextSearch::CountRelatedObjects($sRefClass, $sKey);
		$aClasses = array();
		foreach($aRelatedObjects as $sLinkClass => $iCount)
		{
			$sClassName = MetaModel::GetName($sLinkClass);
			// Note: border set to 0 due to various browser interpretations (IE9 adding a 2px border)
			$sClassIcon = MetaModel::GetClassIcon($sLinkClass, true, 'float;left;margin-right:10px;border:0;');
			$sFilter = FullTextSearch::GetRelatedObjectsFilter($sRefClass, $sKey, $sLinkClass);
			$sHref = utils::GetAbsoluteUrlAppRoot().'pages/UI.php?operation=search&filter='.rawurlencode($sFilter);
			$aClasses[$sClassName] = array('class' => $sLinkClass, 'count' => $iCount, 'icon' => $sClassIcon, 'name' => $sClassName, 'href' => $sHref);
		}
		if (!empty($aClasses))
		{
			ksort($aClasses);
		}
		$aParams['aClasses'] = $aClasses;

		$this->AddSaas('env-'.utils::GetCurrentEnvironment().'/'.FullTextUtils::GetModuleName().'/css/'.FullTextUtils::GetModuleName().'.scss');

		$this->DisplayPage($aParams);
	}

	/**
	 * @throws \ArchivedObjectException
	 * @throws \CoreException
	 * @throws \DictExceptionMissingString
	 */
	public function Operationfull_text()
	{
		$this->OperationSearch();
	}

	/**
	 * @throws \ArchivedObjectException
	 * @throws \CoreException
	 * @throws \DictExceptionMissingString
	 * @throws \Exception
	 */
	public function OperationSearch()
	{
		$aParams = array();

		$sFullText = trim(utils::ReadParam('text', '', false, 'raw_data'));
		$aParams['sFullText'] = $sFullText;
		$sURLFullText = urlencode($sFullText);
		$iLimit = utils::ReadParam('limit', 15);
		$iOffset = utils::ReadParam('offset', 0);
		$aParams['iOffset'] = $iOffset;
		$bDebug = utils::ReadParam('debug', false);
		$aParams['bDebug'] = $bDebug;
		$bOpenMatch = utils::ReadParam('open_match', false) || $bDebug;
		$aParams['bOpenMatch'] = $bOpenMatch;
		$sDebug = '';
		$iCount = 0;
		if ($bDebug)
		{
			$sDebug = '&debug=true';
		}
		$sOpenMatch = '';
		if ($bOpenMatch)
		{
			$sOpenMatch = '&open_match=true';
		}
		$sOffset = '';
		if ($iOffset > 0)
		{
			$sOffset = '&offset='.$iOffset;
		}
		if (empty($sFullText))
		{
			$aResults = array();
		}
		else
		{
			$fStarted = MyHelpers::getmicrotime();
			$iCount = FullTextSearch::Count($sFullText);
			$aParams['iCount'] = $iCount;
			$aResults = FullTextSearch::Search($sFullText, $iLimit, $iOffset);
			$aParams['fDuration'] = round(MyHelpers::getmicrotime() - $fStarted, 3);
		}

		$aParams['bIsAdministrator'] = UserRights::IsAdministrator();
		if (UserRights::IsAdministrator())
		{
			$aParams['sAdminLink'] = utils::GetAbsoluteUrlModulePage(FullTextUtils::GetModuleName(), 'index-admin.php');
			$sDebugChange = '';
			if (!$bDebug)
			{
				$sDebugChange = '&debug=true';
			}
			$aParams['sDebugLink'] = utils::GetAbsoluteUrlModulePage(FullTextUtils::GetModuleName(), 'index.php').'&operation=Search&text='.$sURLFullText.$sDebugChange.$sOffset;
		}

		if ($bOpenMatch)
		{
			$aParams['sOpenCloseMatchingEntries'] = Dict::S('FulltextSearch:CloseAllMatchingEntries');
			$aParams['sOpenCloseMatchingEntriesLink'] = utils::GetAbsoluteUrlModulePage(FullTextUtils::GetModuleName(), 'index.php').'&operation=Search&text='.$sURLFullText.$sOffset;
		}
		else
		{
			$aParams['sOpenCloseMatchingEntries'] = Dict::S('FulltextSearch:OpenAllMatchingEntries');
			$aParams['sOpenCloseMatchingEntriesLink'] = utils::GetAbsoluteUrlModulePage(FullTextUtils::GetModuleName(), 'index.php').'&operation=Search&open_match=true&text='.$sURLFullText.$sOffset;
		}

		$aParams['bHasResults'] = !empty($aResults);
		if (empty($aResults))
		{
			$aParams['bIsEmptyDatabase'] = false;
			if (UserRights::IsAdministrator())
			{
				$sTableName = FullTextSearch::GetIndexTableName();
				$sCountQuery = "SELECT COUNT(*) FROM $sTableName WHERE 1";
				try
				{
					$iIndexCount = CMDBSource::QueryToScalar($sCountQuery);
				}
				catch (Exception $e)
				{
					$iIndexCount = 0;
				}
				if ($iIndexCount == 0)
				{
					$aParams['sPopulateDatabaseLink'] = utils::GetAbsoluteUrlModulePage(FullTextUtils::GetModuleName(), 'index-admin.php').'&operation=Populate'.$sDebug;
					$aParams['bIsEmptyDatabase'] = true;
				}
			}
			$aParams['aSearchParams'] = FullTextSearch::GetSearchParams($sFullText);
		}
		else
		{
			$fStarted = MyHelpers::getmicrotime();
			// Class drill down
			$aSearchParams = FullTextSearch::GetSearchParams($sFullText);
			$aParams['aSearchParams'] = $aSearchParams;
			$sSearchClass = $aSearchParams['search_class_name'];
			$bDrillDown = empty($sSearchClass);
			$aParams['bDrillDown'] = !$bDrillDown;

			$aCountByClass = FullTextSearch::CountGroupByClasses($sFullText);
			if (!$bDrillDown)
			{
				$sSearch = substr($sFullText, strlen($sSearchClass) + 1);
				$aParams['sDrillDownLink'] = utils::GetAbsoluteUrlModulePage(FullTextUtils::GetModuleName(), 'index.php').'&operation=Search&text='.urlencode($sSearch).$sDebug.$sOpenMatch;
			}

			$aClasses = array();
			foreach($aCountByClass as $aClassCount)
			{
				$sClassName = MetaModel::GetName($aClassCount['class']);
				if ($bDrillDown)
				{
					$sSearch = $sClassName.':'.$sFullText;
				}
				else
				{
					$sSearch = $sFullText;
				}
				$aClassCount['link'] = utils::GetAbsoluteUrlModulePage(FullTextUtils::GetModuleName(), 'index.php').'&operation=Search&text='.urlencode($sSearch).$sDebug.$sOpenMatch;
				$aClassCount['text'] = Dict::Format('FulltextSearch:RelatedByClass', $aClassCount['count'], $sClassName);

				$aClasses[$sClassName] = $aClassCount;
			}
			ksort($aClasses);
			$aParams['aClasses'] = $aClasses;
			$aParams['fDebugDrillDownDuration'] = round(MyHelpers::getmicrotime() - $fStarted, 3);

			// Search Results
			$aSearchResults = array();
			$aParams['sOrgLabel'] = MetaModel::GetName('Organization');
			$iCurrent = 0;
			$aParams['fDebugResultDuration'] = 0;
			$aParams['fDebugMatchesDuration'] = 0;
			foreach ($aResults as $aResult)
			{
				$fStarted = MyHelpers::getmicrotime();
				$sClass = $aResult['obj_class'];
				$aResult['class_name'] = MetaModel::GetName($sClass);
				$aResult['link'] = utils::GetAbsoluteUrlAppRoot().'pages/UI.php?operation=details&class='.$sClass.'&id='.$aResult['obj_key'];

				$oObj = MetaModel::GetObject($sClass, $aResult['obj_key']);
				if (!empty($aResult['org_name']))
				{
					if (($sText = FullTextSearch::GetHighlight($aResult['org_name'], $sFullText)) === false)
					{
						$sText = $aResult['org_name'];
					}
					$aResult['org_name'] = $sText;
				}
				$aZList = MetaModel::GetZListItems($sClass, 'list');
				$aAttrValues = array();
				foreach($aZList as $sAttCode)
				{
					if ($sAttCode == 'org_id')
					{
						continue;
					}
					$oAttDef = MetaModel::GetAttributeDef($sClass, $sAttCode);
					$sValue = trim(strip_tags($oObj->Get($sAttCode)));
					if ($oAttDef->IsExternalKey())
					{
						/** @var AttributeExternalKey $oAttDef */
						$sTargetClass = $oAttDef->GetTargetClass();
						$oTargetObject = MetaModel::GetObject($sTargetClass, $sValue, false);
						if ($oTargetObject)
						{
							$sValue = $oTargetObject->Get('friendlyname');
						}
					}

					if (!empty($sValue))
					{
						$sText = $oAttDef->GetAsPlainText($sValue, $oObj);
						if (($sHighlightedText = FullTextSearch::GetHighlight($sText, $sFullText)) === false)
						{
							$sHighlightedText = $sText;
						}

						$aAttrValues[] = array(
							'label' => MetaModel::GetLabel($sClass, $sAttCode),
							'value' => $sHighlightedText);
					}
				}
				$aResult['zlist'] = $aAttrValues;
				$aParams['fDebugResultDuration'] += MyHelpers::getmicrotime() - $fStarted;

				//
				// Display matching details
				//
				if ($bOpenMatch)
				{
					$fStarted = MyHelpers::getmicrotime();
					$aAttDefs = FullTextSearch::GetObjectAttDefsForIndex($sClass);
					$iMaxLines = 5;
					$aAttrValues = array();
					foreach ($aAttDefs as $oAttDef)
					{
						$sAttCode = $oAttDef->GetCode();
						if (in_array($sAttCode, $aZList))
						{
							continue;
						}

						$sValue = trim(strip_tags($oObj->Get($sAttCode)));
						if ($oAttDef->IsExternalKey())
						{
							/** @var AttributeExternalKey $oAttDef */
							$sTargetClass = $oAttDef->GetTargetClass();
							$oTargetObject = MetaModel::GetObject($sTargetClass, $sValue, false);
							if ($oTargetObject)
							{
								$sValue = $oTargetObject->Get('friendlyname');
							}
						}
						if (!empty($sValue))
						{
							$sText = $oAttDef->GetAsPlainText($oObj->Get($sAttCode));
							if (($sHighlightedText = FullTextSearch::GetHighlight($sText, $sFullText, 25)) !== false)
							{
								$aAttrValues[] = array(
									'label' => MetaModel::GetLabel($sClass, $sAttCode),
									'value' => $sHighlightedText
								);
								if ($iMaxLines-- < 0)
								{
									break;
								}
							}
						}
					}
					$aResult['details'] = $aAttrValues;
					$aParams['fDebugMatchesDuration'] += MyHelpers::getmicrotime() - $fStarted;
				}

				// Link to related objects
				$aResult['related_link'] = utils::GetAbsoluteUrlModulePage(FullTextUtils::GetModuleName(), 'index.php').'&operation=DisplayRelated&class='.$sClass.'&key='.urlencode($aResult['obj_key']).'&friendlyname='.urlencode($aResult['friendlyname']).$sDebug;

				$iCurrent++;
				if (($iLimit > 0) && ($iCurrent > $iLimit))
				{
					break;
				}
				$aSearchResults[] = $aResult;
			}
			$aParams['aResults'] = $aSearchResults;
			$aParams['fDebugMatchesDuration'] = round($aParams['fDebugMatchesDuration'], 3);
			$aParams['fDebugResultDuration'] = round($aParams['fDebugResultDuration'], 3);
		}

		// Pagination
		if ($iCount > $iLimit)
		{
			if ($iOffset > 0)
			{
				$iActual = $iOffset - $iLimit;
				$aParams['sPreviousLink'] = utils::GetAbsoluteUrlModulePage(FullTextUtils::GetModuleName(), 'index.php').'&operation=Search&offset='.$iActual.$sDebug.$sOpenMatch.'&text='.$sURLFullText;
			}
			$iPageMin = max(0, ($iOffset - (5 * $iLimit)) / $iLimit);
			$aPaginationPages = array();
			for($i = $iPageMin; $i < $iPageMin + 10; $i++)
			{
				$iLinkOffset = $i * $iLimit;
				$iPage = $i + 1;
				if ($iLinkOffset == $iOffset)
				{
					$aPaginationPages[] = array(
						'disable' => true,
						'page' => $iPage,
					);
				}
				else
				{
					if ($iLinkOffset < $iCount)
					{
						$aPaginationPages[] = array(
							'disable' => false,
							'link' => utils::GetAbsoluteUrlModulePage(FullTextUtils::GetModuleName(), 'index.php').'&operation=Search&offset='.$iLinkOffset.$sDebug.$sOpenMatch.'&text='.$sURLFullText,
							'page' => $iPage,
						);
					}
				}
			}
			$iActual = $iOffset + $iLimit;
			if ($iActual < $iCount)
			{
				$aParams['sPaginationNextLink'] = utils::GetAbsoluteUrlModulePage(FullTextUtils::GetModuleName(), 'index.php').'&operation=Search&offset='.$iActual.$sDebug.$sOpenMatch.'&text='.$sURLFullText;
			}
			$aParams['aPaginationPages'] = $aPaginationPages;
		}
		$aParams['bHasPendingActions'] = FullTextSearch::HasPendingActions();

		$this->AddSaas('env-'.utils::GetCurrentEnvironment().'/'.FullTextUtils::GetModuleName().'/css/'.FullTextUtils::GetModuleName().'.scss');
		$this->DisplayPage($aParams, 'Search');
	}
}
