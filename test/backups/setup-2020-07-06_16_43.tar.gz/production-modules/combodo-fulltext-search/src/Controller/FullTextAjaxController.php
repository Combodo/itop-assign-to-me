<?php
/**
 * @copyright   Copyright (C) 2010-2020 Combodo SARL
 * @license     http://opensource.org/licenses/AGPL-3.0
 */


namespace Combodo\iTop\FullTextSearch\Controller;


use Combodo\iTop\Application\TwigBase\Controller\Controller;
use Combodo\iTop\FullTextSearch\Service\FullTextIndexer;
use Combodo\iTop\FullTextSearch\Service\FullTextSearch;
use Dict;
use Exception;
use IssueLog;
use MetaModel;
use MyHelpers;
use SetupUtils;
use utils;

class FullTextAjaxController extends Controller
{
	public function OperationRefreshMetrics()
	{
		$aParams = array();
		try
		{
			$aParams['iCountPending'] = FullTextSearch::CountPendingActions('reindex');
			$aParams['iCountRebuild'] = FullTextSearch::CountPendingActions('rebuild');
			$aParams['iCountBuild'] = FullTextSearch::CountPendingActions('build');
			$aParams['sClassToIndex'] = FullTextSearch::GetNextClassToIndex();
			$aParams['iEntries'] = FullTextSearch::TotalSearchEntries();

			$aParams['bSuccess'] = true;
		}
		catch (Exception $e)
		{
			IssueLog::Error($e->getMessage());
			$aParams['sError'] = $e->getMessage();
		}

		$this->DisplayJSONPage($aParams);
	}

	/**
	 * @throws \CoreException
	 * @throws \MySQLException
	 * @throws \MySQLHasGoneAwayException
	 */
	public function OperationReIndex()
	{
		$fStartTime = MyHelpers::getmicrotime();
		$bEraseIndex     = (utils::ReadPostedParam('eraseIndex', 'false') == 'true');
		$bRebuildIndex   = (utils::ReadPostedParam('rebuildIndex', 'false') == 'true');
		$bBackgroundMode = (utils::ReadPostedParam('backgroundMode', 'false') == 'true');


		if ($bEraseIndex)
		{
			// Dropping the database table requires a exclusive access
			SetupUtils::EnterMaintenanceMode(MetaModel::GetConfig());
			sleep(FullTextIndexer::INDEXATION_TIME_SLOT + 1);
			FullTextIndexer::EraseDB();
			FullTextIndexer::CreateFullTextTable();
			SetupUtils::ExitMaintenanceMode();
		}

		if ($bRebuildIndex)
		{
			if (FullTextSearch::TotalSearchEntries(1) > 0)
			{
				$sOperation = OPERATION_REBUILD;
			}
			else
			{
				$sOperation = OPERATION_BUILD;
			}
			FullTextIndexer::PlanForAllIndexRebuild($bBackgroundMode, $sOperation);
		}
		else
		{
			$bCompleted = false;
			while (!$bCompleted && !SetupUtils::IsInMaintenanceMode())
			{
				$bCompleted = FullTextIndexer::ReindexPendingEntries(time() + FullTextIndexer::INDEXATION_TIME_SLOT);
			}
		}

		$iElapsedTime = (int) round(MyHelpers::getmicrotime() - $fStartTime, 3);
		$aParams = array(
			'bSuccess' => true,
			'sElapsed' => Dict::Format('FulltextSearch:ReIndexation:Elapsed', $iElapsedTime),
		);
		$this->DisplayJSONPage($aParams);
	}
}
