<?php
/**
 *
 * @copyright   Copyright (C) 2010-2019 Combodo SARL
 * @license     https://www.combodo.com/documentation/combodo-software-license.html
 *
 */


namespace Combodo\iTop\FullTextSearch;

use Combodo\iTop\FullTextSearch\Controller\FullTextAdminController;
use Combodo\iTop\FullTextSearch\Service\FullTextUtils;

require_once(APPROOT.'application/startup.inc.php');

$sModuleName = FullTextUtils::GetModuleName();
$oUpdateController = new FullTextAdminController(MODULESROOT.$sModuleName.'/view/admin', $sModuleName);
$oUpdateController->AllowOnlyAdmin();
$oUpdateController->SetDefaultOperation('Admin');
$oUpdateController->HandleOperation();

