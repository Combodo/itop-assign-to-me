<?php
/**
 *
 * @copyright   Copyright (C) 2010-2019 Combodo SARL
 * @license     https://www.combodo.com/documentation/combodo-software-license.html
 *
 */
namespace Combodo\iTop\FullTextSearch;

use Combodo\iTop\FullTextSearch\Service\FullTextSearch;
use utils;

@include_once ('../approot.inc.php');
@include_once ('../../approot.inc.php');
@include_once ('../../../approot.inc.php');
require_once(APPROOT.'application/application.inc.php');
require_once(APPROOT.'application/startup.inc.php');

if (!utils::IsModeCLI())
{
	echo "Only CLI mode is allowed";
	return;
}

if (!class_exists('Combodo\iTop\FullTextSearch\Service\FullTextSearch'))
{
	// from the sources !!!
	@include_once(APPROOT.'extensions/combodo-fulltext-search/src/Service/MemoryKpi.php');
	@include_once(APPROOT.'extensions/combodo-fulltext-search/src/Service/MemoryKpiLog.php');
	@include_once(APPROOT.'extensions/combodo-fulltext-search/src/Service/FullTextIndexer.php');
	@include_once(APPROOT.'extensions/combodo-fulltext-search/src/Service/FullTextSearch.php');
	if (!class_exists('Combodo\iTop\FullTextSearch\Service\FullTextSearch'))
	{
		// from the sources !!!
		@include_once(APPROOT.'data/production-modules/combodo-fulltext-search/src/Service/MemoryKpi.php');
		@include_once(APPROOT.'data/production-modules/combodo-fulltext-search/src/Service/MemoryKpiLog.php');
		@include_once(APPROOT.'data/production-modules/combodo-fulltext-search/src/Service/FullTextIndexer.php');
		@include_once(APPROOT.'data/production-modules/combodo-fulltext-search/src/Service/FullTextSearch.php');
	}
	if (!class_exists('Combodo\iTop\FullTextSearch\Service\FullTextSearch'))
	{
		echo "Missing Fulltext Search Extension";
		return;
	}
}

function getmicrotime()
{
	list($usec, $sec) = explode(" ",microtime());
	return ((float)$usec + (float)$sec);
}

set_time_limit(0);
$fStart = FullTextSearch::GetMicroTime();
$iCount = FullTextSearch::CountPendingActions();
FullTextSearch::ReindexPendingEntries();
$fDuration = FullTextSearch::GetMicroTime() - $fStart;
$fRate = round($iCount / $fDuration);
$fDuration = round($fDuration);

echo "Refresh Fulltext Index: {$iCount} entries in {$fDuration}s ({$fRate} index/s)";



