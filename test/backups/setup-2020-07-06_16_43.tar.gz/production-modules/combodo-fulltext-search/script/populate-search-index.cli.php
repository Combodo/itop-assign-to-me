<?php
/**
 *
 * @copyright   Copyright (C) 2010-2019 Combodo SARL
 * @license     https://www.combodo.com/documentation/combodo-software-license.html
 *
 */

namespace Combodo\iTop\FullTextSearch;

use Combodo\iTop\FullTextSearch\Service\FullTextSearch;
use Combodo\iTop\FullTextSearch\Service\MemoryKpiLog;
use utils;

@include_once ('../approot.inc.php');
@include_once ('../../approot.inc.php');
@include_once ('../../../approot.inc.php');
require_once(APPROOT.'application/application.inc.php');
require_once(APPROOT.'application/startup.inc.php');

if (!utils::IsModeCLI())
{
	echo "Only CLI mode is allowed";
	return;
}

if (!class_exists('Combodo\iTop\FullTextSearch\Service\FullTextSearch'))
{
	// from the sources !!!
	@include_once(APPROOT.'extensions/combodo-fulltext-search/src/Service/MemoryKpi.php');
	@include_once(APPROOT.'extensions/combodo-fulltext-search/src/Service/MemoryKpiLog.php');
	@include_once(APPROOT.'extensions/combodo-fulltext-search/src/Service/FullTextIndexer.php');
	@include_once(APPROOT.'extensions/combodo-fulltext-search/src/Service/FullTextSearch.php');
	if (!class_exists('Combodo\iTop\FullTextSearch\Service\FullTextSearch'))
	{
		// from the sources !!!
		@include_once(APPROOT.'data/production-modules/combodo-fulltext-search/src/Service/MemoryKpi.php');
		@include_once(APPROOT.'data/production-modules/combodo-fulltext-search/src/Service/MemoryKpiLog.php');
		@include_once(APPROOT.'data/production-modules/combodo-fulltext-search/src/Service/FullTextIndexer.php');
		@include_once(APPROOT.'data/production-modules/combodo-fulltext-search/src/Service/FullTextSearch.php');
	}
	if (!class_exists('Combodo\iTop\FullTextSearch\Service\FullTextSearch'))
	{
		echo "Missing Fulltext Search Extension";
		return;
	}
}

set_time_limit(0);
$fStart = FullTextSearch::GetMicroTime();
FullTextSearch::PopulateDB();
$fDuration = FullTextSearch::GetMicroTime() - $fStart;
$iCount = FullTextSearch::TotalSearchEntries();
$fRate = round($iCount / $fDuration);
$fDuration = round($fDuration);

echo "Populate Database: {$iCount} entries in {$fDuration}s ({$fRate} index/s)\n";

$sLimit = ini_get('memory_limit');
echo 'Memory limit is: '.$sLimit."\n";
echo 'Memory peak is:  '.round(memory_get_peak_usage(true)/1024/1024, 2)."M\n";

$aMemoryLogs = MemoryKpiLog::GetLog();
foreach($aMemoryLogs as $sMemLog)
{
	echo "$sMemLog";
}
