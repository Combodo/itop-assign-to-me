<?php

use Combodo\iTop\FullTextSearch\Service\FullTextSearch;
use Combodo\iTop\FullTextSearch\Service\FullTextUtils;

/**
 *
 * @copyright   Copyright (C) 2010-2019 Combodo SARL
 * @license     https://www.combodo.com/documentation/combodo-software-license.html
 *
 */

class FullTextBackgroundRefresh implements iBackgroundProcess
{
	private $iPeriod;
	private $iMaxIndexationTime;

	public function __construct()
	{
		$this->iPeriod = MetaModel::GetModuleSetting(FullTextUtils::GetModuleName(), 'background_index_refresh_period_in_min', 2) * 60;
		$this->iMaxIndexationTime = MetaModel::GetModuleSetting(FullTextUtils::GetModuleName(), 'background_max_indexation_time_in_min', 1) * 60;
	}

	public function GetPeriodicity()
	{
		return $this->iPeriod;
	}

	public function Process($iUnixTimeLimit)
	{
		$iMaxTime = time() + $this->iMaxIndexationTime;
		if ($iMaxTime > $iUnixTimeLimit)
		{
			$iMaxTime = $iUnixTimeLimit;
		}
		FullTextSearch::ReindexPendingEntries($iMaxTime);
	}
}

if (class_exists('AbstractWeeklyScheduledProcess'))
{
	class FullTextBackgroundRebuildFullIndex extends AbstractWeeklyScheduledProcess
	{
		const DEFAULT_MODULE_SETTING_ENABLED = false;
		const MODULE_SETTING_ENABLED = 'background_index_full_rebuild_enabled';
		const MODULE_SETTING_WEEKDAYS = 'background_index_full_rebuild_week_days';
		const MODULE_SETTING_TIME = 'background_index_full_rebuild_time';

		public function Process($iUnixTimeLimit)
		{
			set_time_limit(0);
			try
			{
				FullTextSearch::PlanForAllIndexRebuild();
			} catch (Exception $e)
			{
				IssueLog::Error($e->getMessage());
			}
		}

		/**
		 * @inheritDoc
		 */
		protected function GetModuleName()
		{
			return FullTextUtils::GetModuleName();
		}

		/**
		 * @inheritDoc
		 */
		protected function GetDefaultModuleSettingTime()
		{
			return '01:30';
		}

		public function GetDisplayStatus()
		{
			$bEnabled = MetaModel::GetConfig()->GetModuleSetting(
				FullTextUtils::GetModuleName(),
				static::MODULE_SETTING_ENABLED,
				static::DEFAULT_MODULE_SETTING_ENABLED
			);
			if (!$bEnabled)
			{
				return Dict::S('FulltextSearch:NoRebuildFullIndex');
			}

			// Week Days
			//
			$aWeekDayToString = array(
				1 => Dict::S('DayOfWeek-Monday'),
				2 => Dict::S('DayOfWeek-Tuesday'),
				3 => Dict::S('DayOfWeek-Wednesday'),
				4 => Dict::S('DayOfWeek-Thursday'),
				5 => Dict::S('DayOfWeek-Friday'),
				6 => Dict::S('DayOfWeek-Saturday'),
				7 => Dict::S('DayOfWeek-Sunday')
			);
			$aDayLabels = array();
			foreach ($this->InterpretWeekDays() as $iDay)
			{
				$aDayLabels[] = $aWeekDayToString[$iDay];
			}
			$sDays = implode(', ', $aDayLabels);
			$sProcessTime = MetaModel::GetConfig()->GetModuleSetting(FullTextUtils::GetModuleName(), static::MODULE_SETTING_TIME, $this->GetDefaultModuleSettingTime());
			return Dict::Format('FulltextSearch:WeekDaysRebuildFullIndex', $sDays, $sProcessTime);
		}
	}
}
else
{
	class FullTextBackgroundRebuildFullIndex implements iScheduledProcess
	{
		private $bEnabled;
		private $sTime;

		public function __construct()
		{
			$this->bEnabled = MetaModel::GetConfig()->GetModuleSetting(FullTextUtils::GetModuleName(), 'background_index_full_rebuild_enabled', false);
			$this->sTime = MetaModel::GetConfig()->GetModuleSetting(FullTextUtils::GetModuleName(), 'background_index_full_rebuild_time', '23:30');
		}

		public function Process($iUnixTimeLimit)
		{
			set_time_limit(0);
			try
			{
				FullTextSearch::PlanForAllIndexRebuild();
			}
			catch (Exception $e)
			{
				IssueLog::Error($e->getMessage());
			}
		}


		/**
		 * @return \DateTime
		 * @throws \Exception
		 */
		public function GetNextOccurrence()
		{
			if (!$this->bEnabled)
			{
				$oRet = new DateTime('3000-01-01');
			}
			else
			{
				if (!preg_match('/[0-2][0-9]:[0-5][0-9]/', $this->sTime))
				{
					throw new Exception("'combodo-fulltext-search: wrong format for setting 'time' (found '$this->sTime')");
				}

				$oRet = new DateTime();
				$sCurTime = $oRet->format('H:i');
				list($sCurHours, $sCurMinutes) = explode(':', $sCurTime);
				list($sHours, $sMinutes) = explode(':', $this->sTime);
				if (((int)$sCurHours > (int)$sHours) || (((int)$sCurHours === (int)$sHours) && ((int)$sCurMinutes > (int)$sMinutes)))
				{
					// Modify days only if the time is already passed
					$oRet->modify("+1 day");
				}
				$oRet->setTime((int)$sHours, (int)$sMinutes);
			}
			return $oRet;
		}
	}
}
